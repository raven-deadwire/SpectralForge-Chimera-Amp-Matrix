from __future__ import annotations
import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path('/workspace/scratch/b934cbc39d7c/chimera-integration')
OUT = Path('/workspace/scratch/b934cbc39d7c/evidence/installer-9375328c')
EXPECTED = '9375328c30dfe5908e5010342179b5afbc258900'
DONOR = '068f1547face75b34c1760dd7b8c9d34868a5393'
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / 'Tools'))
import legacy_document_cleanup as posix
import windows_document_rules as windows
import package_release as package
import check_public_names

def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args], text=True).strip()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def run(action, *args):
    result = subprocess.run([str(helper), action, *map(str,args)], text=True, capture_output=True, timeout=60)
    calls.append({'action': action, 'exit_code': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr})
    assert result.returncode == 0, result.stderr

before = {'sha': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'), 'status': git('status', '--porcelain=v1')}
assert before['sha'] == EXPECTED and before['status'] == ''
inventory_path = ROOT / 'Validation/legacy-document-inventory.json'
inventory_bytes = inventory_path.read_bytes()
inventory = json.loads(inventory_bytes)
donor_inventory = subprocess.check_output(['git', '-C', str(ROOT), 'show', DONOR + ':Validation/legacy-document-inventory.json'])
assert inventory_bytes == donor_inventory
work = OUT / 'current-document-probe'
stage = work / 'source-documents'
assert not work.exists(), 'Refuse to overwrite prior evidence'
stage.mkdir(parents=True)
documents = {'COPYRIGHT.txt': ROOT / 'COPYRIGHT.txt', **{name: ROOT / 'docs' / name for name in package.PUBLIC_DOCUMENTS}}
check_public_names.validate_document_names(package.PUBLIC_DOCUMENTS)
fingerprints = {}
for name, source in documents.items():
    check_public_names.validate_document(source)
    content = source.read_bytes()
    (stage / name).write_bytes(content)
    fingerprints[name] = {'bytes': len(content), 'sha256': sha(content)}
for name in ('MANUAL.html', 'PRESETS.md'):
    content = (stage / name).read_bytes()
    assert b'Metal Clank' in content and b'Heavy Pulse' in content
    assert b'Clear Clank' not in content and b'Clean Low Pulse' not in content

posix_counts = {}
for target in ('linux', 'macos'):
    rules = posix.document_rules(platform=target, current_documents=stage)
    current = {r['path']: r for r in rules if r['current']}
    assert set(current) == set(documents)
    for name, item in fingerprints.items():
        assert current[name]['current_fingerprint'] == (item['bytes'], item['sha256'])
        assert not current[name]['retire']
    posix_counts[target] = {'total_paths': len(rules), 'current_source_documents': len(current)}

windows_rules = windows.document_rules(inventory, stage)
for name, item in fingerprints.items():
    assert (windows.install_path(name), item['bytes'], item['sha256'], False, windows.is_notice(name)) in windows_rules
generated = windows.render_rules(inventory, stage)
(work / 'WindowsDocumentRules.iss').write_text(generated, encoding='utf-8')

helper = posix.build_helper(work / 'document-maintenance', platform='linux', current_documents=stage)
target = (work / '통합 문서 검증').resolve()
calls = []
run('install-documents', stage.resolve(), target)
for name, source in documents.items():
    assert (target / name).read_bytes() == source.read_bytes()
edited = {}
for name in ('MANUAL.html', 'PRESETS.md'):
    data = (target / name).read_bytes() + b'\nUser document annotation preserved across name integration.\n'
    (target / name).write_bytes(data)
    edited[name] = data
user_files = {'personal.chimera': b'user preset identity fixture', 'personal.wav': b'user IR fixture', 'existing-project.song': b'user project state fixture'}
for name, data in user_files.items():
    (target / name).write_bytes(data)
run('install-documents', stage.resolve(), target)
for name, source in documents.items():
    assert (target / name).read_bytes() == source.read_bytes()
for name, data in edited.items():
    preserved = Path(str(target) + '.preserved') / sha(data) / name
    assert preserved.read_bytes() == data
for name, data in user_files.items():
    assert (target / name).read_bytes() == data
# A new edit after repair must survive document-only removal in place.
after_repair_edit = (target / 'MANUAL.html').read_bytes() + b'\nUser edit after repair.\n'
(target / 'MANUAL.html').write_bytes(after_repair_edit)
run('remove-documents', target)
assert (target / 'MANUAL.html').read_bytes() == after_repair_edit
assert not (target / 'PRESETS.md').exists()
for name in ('COPYRIGHT.txt', 'THIRD_PARTY_NOTICES.md'):
    assert (target / name).read_bytes() == documents[name].read_bytes()
for name, data in edited.items():
    assert (Path(str(target) + '.preserved') / sha(data) / name).read_bytes() == data
for name, data in user_files.items():
    assert (target / name).read_bytes() == data
after = {'sha': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'), 'status': git('status', '--porcelain=v1')}
assert after == before and inventory_path.read_bytes() == inventory_bytes
result = {'schema': 'chimera.integrated-current-document-probe.v1', 'success': True,
          'source_sha': EXPECTED, 'before': before, 'after': after,
          'historical_inventory_byte_equal_donor': DONOR, 'historical_inventory_sha256': sha(inventory_bytes),
          'scope': '12 exact source-authored public documents from integrated source, generated current Windows/Linux/macOS rules, Linux native document-only fresh/repair/remove. Excludes build-generated Verification.txt, README.txt and payload-manifest.json and all product binaries/installers.',
          'source_documents': fingerprints, 'posix_rule_counts': posix_counts,
          'windows_rule_variants': len(windows_rules), 'native_calls': calls,
          'checks': ['Metal Clank and Heavy Pulse present in exact MANUAL/PRESETS bytes; superseded labels absent',
                     'All staged current documents have exact SHA/size in Windows/Linux/macOS rules and no retirement flag',
                     'Linux native fresh copy matches all 12 integrated source files',
                     'Repair installs integrated current bytes and preserves edited manual/presets byte-for-byte',
                     'Document-only removal preserves new manual edits, prior snapshots, license notices and personal sentinel files',
                     'Historical inventory is byte-identical to #58 donor; source tree remains clean and unchanged'],
          'native_product_installation_verified': False, 'windows_native_installer_verified': False,
          'macos_native_installer_verified': False, 'daw_audio_verified': False, 'publication_approved': False,
          'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
(OUT / 'current-documents-results.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k not in ('source_documents','native_calls')}, ensure_ascii=False, indent=2))
