from __future__ import annotations
import concurrent.futures
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import sys

ROOT = Path('/workspace/scratch/b934cbc39d7c/chimera-integration')
OUT = Path('/workspace/scratch/b934cbc39d7c/evidence/installer-9375328c')
EXPECTED = '9375328c30dfe5908e5010342179b5afbc258900'
DONOR = '068f1547face75b34c1760dd7b8c9d34868a5393'

def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args], text=True).strip()

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def snapshot():
    return {'source_sha': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'status_porcelain': git('status', '--porcelain=v1'),
            'inventory_blob': git('hash-object', 'Validation/legacy-document-inventory.json'),
            'inventory_sha256': digest(ROOT / 'Validation/legacy-document-inventory.json')}

report = {'schema': 'chimera.integration-installer-checks.v1', 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'expected_source_sha': EXPECTED, 'donor_source_sha': DONOR, 'before': snapshot(),
          'platform': platform.platform(), 'euid': os.geteuid(), 'python': sys.executable,
          'scope': 'Fresh POSIX native document helper including isolated real dpkg synthetic fixtures; portable Windows rules; integrated current-document fingerprint semantics. No product installer, Windows Inno, macOS PKG, DAW or publication acceptance.',
          'native_product_installation_verified': False, 'publication_approved': False}
assert report['before']['source_sha'] == EXPECTED
assert report['before']['status_porcelain'] == ''
donor_blob = git('rev-parse', DONOR + ':Validation/legacy-document-inventory.json')
report['donor_inventory_blob'] = donor_blob
assert report['before']['inventory_blob'] == donor_blob

def run_suite(name, args):
    command = [sys.executable, '-B', *args]
    env = os.environ.copy()
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    started = datetime.datetime.now(datetime.timezone.utc)
    result = subprocess.run(command, cwd=ROOT, env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=240)
    (OUT / (name + '.log')).write_text(result.stdout, encoding='utf-8')
    count = re.search(r'Ran (\d+) tests? in', result.stdout)
    skips = [line for line in result.stdout.splitlines() if '... skipped ' in line]
    return {'name': name, 'command': command, 'exit_code': result.returncode,
            'started_utc': started.isoformat(), 'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'tests_run': int(count.group(1)) if count else None, 'skip_reasons': skips,
            'log': str(OUT / (name + '.log'))}

with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    jobs = [pool.submit(run_suite, 'native-helper', ['Tools/test_legacy_document_cleanup.py']),
            pool.submit(run_suite, 'windows-rules', ['-m', 'unittest', 'Tests.test_windows_document_rules', '-v'])]
    report['suites'] = [f.result() for f in jobs]
report['after'] = snapshot()
assert report['after'] == report['before'], 'Test execution changed tracked source or inventory'
report['success'] = all(x['exit_code'] == 0 for x in report['suites'])
report['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
(OUT / 'suite-results.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(report, ensure_ascii=False, indent=2))
sys.exit(0 if report['success'] else 1)
