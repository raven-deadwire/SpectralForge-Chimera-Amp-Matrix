# Fresh native processor and state evidence — 9375328c

Source `9375328c30dfe5908e5010342179b5afbc258900`, tree `b02780be13bb594074bf51b269f804b4c861e5a4`, clean before and after verification. The independent Linux build was freshly reconfigured to generate the new source identity, then the GateProcessor, UI, and IntegratedProcessor targets were rebuilt and linked successfully. Original `chimera-build-version.json` confirms the new source; original configure/progress logs, execution metadata, and binary hashes are retained.

Fresh CTest execution ran from 2026-10-13 03:46:33 to 03:47:15 UTC:

| CTest | Result | Time |
|---|---|---:|
| ChimeraNativeStateTests | PASS | 5.04148 s |
| ChimeraGateProcessorTests | PASS | 12.1027 s |
| ChimeraNiflheimrPresetTests | PASS | 24.0338 s |

Three tests passed, none failed or skipped; total wall time 41.18 seconds. The test inventory, verbose output, original JUnit, original LastTest.log, newly generated native-state report, and all newly generated preset state reports/snapshots are included. Generated output from the prior source was moved out before execution and is excluded here. No previous-source PASS was reused.

These tests exercise processor/APVTS host contracts, saved-state behavior, and Niflheimr preset behavior, including IDs 43 Metal Clank and 45 Heavy Pulse. They do not establish native-window UI, installed-product, real DAW, or hardware/listening acceptance. The earlier local Xvfb setup failure remains historical environmental evidence and was not retried or relabeled. Fresh Windows CI must execute the full caption-sensitive UI suite.

The root's preliminary `evidence/native/test-caption-fix-build.log` records compilation before the new source freeze. It is compilation evidence only and is not part of this new-source acceptance bundle. `provenance.json` hashes the new full build log; `original-build-steps.log` preserves its exact progress/link lines. `durable-file-index.json` hashes every retained file.
