python -m py_compile Tools/package_release.py Tools/publish_beta111.py Tools/publish_beta112.py Tools/publish_beta12.py Tools/publish_beta13.py Tools/evaluate_release_gate.py Tools/test_release_gate.py Tools/evaluate_signature_benchmark.py Tools/test_signature_benchmark.py Tools/release_evidence.py Tools/produce_release_evidence.py Tools/consolidate_release_gate.py Tools/check_ir_distribution.py Tests/test_ir_distribution.py
python Tools/test_release_gate.py
python Tools/test_release_scope.py
python Tools/test_signature_benchmark.py
python Tools/check_catalog_contract.py
python Tools/check_ir_distribution.py
python Tests/test_ir_distribution.py
python Tools/test_validation_producer.py
python Tools/test_ctest_validation.py
python Tools/test_release_consolidator.py
python Tools/test_publish_beta112.py
python Tools/test_publish_beta12.py
python Tools/test_publish_beta13.py
python Tools/test_beta_publication.py
python Tools/test_publish_beta131.py
python Tools/test_beta_publication131.py
python Tools/test_release_preflight.py
python Tools/test_callback_timing_protocol.py
