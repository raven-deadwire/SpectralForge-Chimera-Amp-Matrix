#!/usr/bin/env python3
"""Execute existing build workflow contracts for one immutable local source."""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import re
import subprocess
import sys
import time

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--repo', type=Path, required=True)
parser.add_argument('--source-sha', required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
repo = args.repo.resolve()
sha = args.source_sha
out = args.output.resolve()
base = 'f8a2d9988a7462b6af6819d25359e0a3e3404f84'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=repo, text=True).strip()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                    ensure_ascii=False, allow_nan=False).encode()).hexdigest()


def assert_clean():
    assert git('rev-parse', 'HEAD') == sha, 'Source SHA changed'
    assert git('status', '--porcelain=v1') == '', 'Source worktree is dirty'


def run(label, command):
    assert_clean()
    started = time.monotonic()
    with (out / (label + '.log')).open('w') as log:
        result = subprocess.run(command, cwd=repo, stdout=log, stderr=subprocess.STDOUT)
    item = {'label': label, 'command': command, 'exit_code': result.returncode,
            'seconds': round(time.monotonic() - started, 3), 'log': str(out / (label + '.log'))}
    print(json.dumps(item), flush=True)
    assert_clean()
    return item


assert re.fullmatch(r'[0-9a-f]{40}', sha)
assert_clean()
out.mkdir(parents=True, exist_ok=True)
source = (repo / '.github/workflows/build.yml').read_text()
lines = source.splitlines()
meta = {'source_sha': sha, 'source_tree': git('rev-parse', 'HEAD^{tree}'),
        'repository_path': str(repo), 'runner_file_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'baseline_sha': base, 'started_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'python': subprocess.check_output(['python', '--version'], text=True).strip(),
        'source_status_before': git('status', '--porcelain=v1'),
        'workflow_file_sha256': hashlib.sha256(source.encode()).hexdigest(),
        'blocks': [], 'policy_files': {}, 'runs': []}

for slug, name in [('validation-contract', 'Verify catalog and validation producer contracts'),
                   ('packaging-contract', 'Check release packaging and validation syntax')]:
    start = lines.index('      - name: ' + name)
    location = next(i for i in range(start, len(lines)) if lines[i] == '        run: |')
    block = []
    for line in lines[location + 1:]:
        if not line.strip():
            block.append('')
            continue
        if not line.startswith('          '):
            break
        block.append(line[10:])
    original = '\n'.join(block).rstrip() + '\n'
    executed = original.replace('${{ github.event.pull_request.head.sha || github.sha }}', sha)
    executed = executed.replace('--output build/validation', '--output ' + str(out / 'validation'))
    assert '${{' not in executed
    (out / (slug + '.original.sh')).write_text(original)
    (out / (slug + '.sh')).write_text(executed)
    meta['blocks'].append({'name': name, 'slug': slug, 'source_line': location + 2,
                           'original_sha256': hashlib.sha256(original.encode()).hexdigest(),
                           'executed_sha256': hashlib.sha256(executed.encode()).hexdigest(),
                           'substitutions': ['exact source SHA', 'seed output directory']
                           if executed != original else []})

for path in ['Validation/release-policy.json', 'Validation/ci-check-map.json',
             'Validation/weekly-publication-policy.json', 'Validation/waivers.json']:
    raw = (repo / path).read_bytes()
    old = subprocess.check_output(['git', 'show', base + ':' + path], cwd=repo)
    assert raw == old, path + ' differs from frozen policy'
    obj = json.loads(raw)
    meta['policy_files'][path] = {'byte_equal_to_baseline': True,
                                 'file_sha256': hashlib.sha256(raw).hexdigest(),
                                 'canonical_sha256': digest(obj)}
    if path.endswith('/release-policy.json'):
        meta['validation_rules_sha256'] = digest({k: v for k, v in obj.items() if k != 'release_scope'})
        meta['release_scope'] = obj['release_scope']
    if path.endswith('/weekly-publication-policy.json'):
        meta['weekly_receipt'] = {k: v for k, v in obj.items() if k != 'required_ci_checks'}
    if path.endswith('/waivers.json'):
        meta['waivers'] = obj

(out / 'source-contract-metadata.json').write_text(json.dumps(meta, ensure_ascii=False, indent=2) + '\n')
meta['runs'].append(run('source-version', ['python', 'Tools/chimera_version.py',
                                         '--target-version', '1.3.1-beta.2', '--source-sha', sha]))
for block in meta['blocks']:
    meta['runs'].append(run(block['slug'], ['bash', '--noprofile', '--norc', '-e', '-o', 'pipefail',
                                          '-x', str(out / (block['slug'] + '.sh'))]))
meta['runs'].append(run('publish-dry-run', ['python', 'Tools/publish_release.py', '--dry-run',
                                          '--target-version', '1.3.1-beta.2', '--source-sha', sha]))

suite_runs = []
for block in meta['blocks']:
    log = (out / (block['slug'] + '.log')).read_text()
    command, suite = None, None
    for line in log.splitlines():
        if line.startswith('+ python '):
            command = line[len('+ '):]
        matched = re.fullmatch(r'Ran (\d+) tests? in ([0-9.]+)s', line)
        if matched:
            suite = {'block': block['slug'], 'command': command, 'tests': int(matched[1]),
                     'seconds': float(matched[2]), 'skipped': 0, 'status': None}
            suite_runs.append(suite)
        if suite is not None and (line == 'OK' or line.startswith('OK (') or line.startswith('FAILED')):
            suite['status'] = line
            skipped = re.search(r'skipped=(\d+)', line)
            suite['skipped'] = int(skipped[1]) if skipped else 0

unique = {}
for suite in suite_runs:
    old = unique.get(suite['command'])
    if old is not None:
        assert old['tests'] == suite['tests'], 'Repeated suite count changed'
        assert old['skipped'] == suite['skipped'], 'Repeated suite skip count changed'
    unique[suite['command']] = suite
meta['unit_test_suites'] = suite_runs
meta['unit_test_counts'] = {
    'suite_executions': len(suite_runs),
    'test_executions_including_repeated_suites': sum(x['tests'] for x in suite_runs),
    'skips_including_repeated_suites': sum(x['skipped'] for x in suite_runs),
    'unique_suite_commands': len(unique),
    'unique_tests_discovered': sum(x['tests'] for x in unique.values()),
    'unique_tests_skipped': sum(x['skipped'] for x in unique.values()),
    'unique_tests_passed': sum(x['tests'] - x['skipped'] for x in unique.values())
}
assert_clean()
meta['source_status_after'] = git('status', '--porcelain=v1')
meta['finished_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
meta['all_commands_succeeded'] = all(x['exit_code'] == 0 for x in meta['runs'])
(out / 'source-contract-results.json').write_text(json.dumps(meta, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'source_sha': sha, 'all_commands_succeeded': meta['all_commands_succeeded'],
                  'unit_test_counts': meta['unit_test_counts'], 'source_clean_after': True}), flush=True)
sys.exit(0 if meta['all_commands_succeeded'] else 1)
