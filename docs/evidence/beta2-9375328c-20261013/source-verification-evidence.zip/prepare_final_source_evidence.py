#!/usr/bin/env python3
"""Bundle selected original evidence without changing the product checkout."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--selection', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
root = Path('/workspace/scratch/b934cbc39d7c')
repo = root / 'chimera-integration'
selection = json.loads(args.selection.read_text())
source = selection['source_sha']
def git(*params):
    return subprocess.check_output(['git', '-C', str(repo), *params], text=True).strip()
def digest(raw):
    return hashlib.sha256(raw).hexdigest()
assert git('rev-parse', 'HEAD') == source
assert not git('status', '--porcelain=v1')
paths = [root / name for name in selection['files']]
for path in paths:
    assert path.resolve().is_relative_to((root / 'evidence').resolve())
    assert not any(part.startswith('transfer') for part in path.parts)
    assert path.is_file(), str(path)
paths += [Path(__file__).resolve(), args.selection.resolve()]
manifest = {
    'schema': 'chimera.source-specific-verification-bundle.v1',
    'source_sha': source,
    'source_tree': git('rev-parse', 'HEAD^{tree}'),
    'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'evidence_only': True,
    'old_source_pass_reused': False,
    'production_source_clean': True,
    'publication_authorized': False,
    'historical_failed_integration_evidence': {
        'source_sha': 'c3e9d436fbdc9b8778b592f333c93037b012b8c5',
        'evidence_commit': 'b912d14e2b39dc81a8cf67edfbb4b4aed2bf2feb',
        'url': 'https://github.com/raven-deadwire/SpectralForge-Chimera-Amp-Matrix/tree/b912d14e2b39dc81a8cf67edfbb4b4aed2bf2feb/docs/evidence/beta2-integration-20261013',
        'qualifies_current_source': False,
    },
    'files': [],
}
args.output.mkdir(parents=True, exist_ok=True)
archive = args.output / 'source-verification-evidence.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    for path in sorted(set(paths)):
        raw = path.read_bytes()
        name = str(path.relative_to(root))
        manifest['files'].append({'path': name, 'bytes': len(raw), 'sha256': digest(raw)})
        bundle.writestr(name, raw)
    bundle.writestr('source-verification-manifest.json', json.dumps(manifest, indent=2) + '\n')
raw = archive.read_bytes()
manifest['archive'] = {'filename': archive.name, 'bytes': len(raw), 'sha256': digest(raw)}
(args.output / 'source-verification-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
assert git('rev-parse', 'HEAD') == source and not git('status', '--porcelain=v1')
print(json.dumps({'source_sha': source, 'files': len(manifest['files']), 'archive': manifest['archive']}, indent=2))
