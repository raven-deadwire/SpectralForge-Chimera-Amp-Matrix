# CAB realtime performance

Result: **FAIL**

Candidate: `022244e6ce845669665e9ffdfefe25bdee154b75`
Baseline: `aaa1330dd5cf7d51faf1c45a7cef633b9b118458`

Both revisions run sequentially on this runner, in separate Release builds.
The baseline is a measured reference. Candidate CTest and its unchanged p99 deadlines determine acceptance.

| Evidence | Complete | CTest exit | Deadline routes passing |
|---|---|---:|---:|
| Baseline | True | 0 | 36/36 |
| Candidate | True | 8 | 65/66 |

Instrumented diagnostic: complete=True, exit=0. Its timing does not replace CTest acceptance.

## Same-runner 96 kHz / 64-sample comparison

| Engine | Channels | Baseline p99 µs | Candidate p99 µs | Deadline µs | Baseline / candidate misses |
|---|---:|---:|---:|---:|---|
| original-v1 | 1 | 340.458 | 130.875 | 666.667 | 0/1600 / 1/1600 |
| original-v1 | 2 | 299.583 | 177.959 | 666.667 | 0/1600 / 0/1600 |
| expanded-v2 | 1 | 360.000 | 109.291 | 666.667 | 4/1600 / 1/1600 |
| expanded-v2 | 2 | 396.458 | 219.583 | 666.667 | 4/1600 / 2/1600 |
| array-v3-6x10 | 1 | 309.125 | 100.083 | 666.667 | 2/1600 / 0/1600 |
| array-v3-6x10 | 2 | 377.917 | 213.458 | 666.667 | 1/1600 / 2/1600 |

Complete route/phase/profile tables, all candidate and diagnostic callback CSVs, full logs, compiler configuration, source/tree SHAs and file hashes are in the artifact.
Raw wall time and CPU clocks are paired by callback index. Windows cycles remain cycles; they are not elapsed microseconds or a scheduling-only diagnosis.
