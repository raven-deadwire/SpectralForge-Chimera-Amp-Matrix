# Exact-source CAB realtime verification

Product source: `c3e9d436fbdc9b8778b592f333c93037b012b8c5`  
Product tree: `9f147ca042491a56af6373592707bf2f6179b4c1`  
Fresh run: [38335147293, attempt 1](https://github.com/raven-deadwire/SpectralForge-Chimera-Amp-Matrix/actions/runs/38335147293)

## Result and limits

The unchanged existing CAB p99 gates passed on the new product source on Windows, Linux, and macOS. Each platform completed all five candidate CTests and all 66 route p99 checks. No old-source PASS was reused. No rerun, source change, timing threshold change, waiver, or acceptance-policy change was made by this verification task.

| Platform | Candidate CTests | Route p99 checks | Callbacks | Individual callback deadline misses |
| --- | --- | --- | --- | --- |
| Windows | 5/5 PASS | 66/66 PASS | 105,600 | 0 |
| Linux | 5/5 PASS | 66/66 PASS | 105,600 | 2 |
| macOS | 5/5 PASS | 66/66 PASS | 105,600 | 76 |

Passing p99 checks does not mean that every callback met its deadline. These measurements do not establish DAW, listening, installer, or release approval.

## Preserved earlier macOS failure

[Run 38333154140](https://github.com/raven-deadwire/SpectralForge-Chimera-Amp-Matrix/actions/runs/38333154140), source `022244e6ce845669665e9ffdfefe25bdee154b75`, failed the extended expanded-v2 route at 96 kHz, 32 samples, stereo. The original candidate result was 4/5 CTests and 65/66 p99 routes passing. The failed artifact remains preserved here as historical evidence; fresh success does not erase or explain its failure.

| Same route, separate macOS runs | Old source 022244e6 | New source c3e9d436 |
| --- | --- | --- |
| Deadline | 333.333 microseconds | 333.333 microseconds |
| Wall p99 | 410.208 microseconds | 157.167 microseconds |
| Thread CPU p99 | 344.250 microseconds | 160.375 microseconds |
| Wall maximum | 3,180.875 microseconds | 892.042 microseconds |
| Deadline misses | 23/1,600 | 3/1,600 |
| Gate | FAIL | PASS |

These are observations from separate runs, not a controlled performance-improvement comparison. In the old run the exact callback at wall p99 also had thread CPU time 411.375 microseconds, so the failure cannot be attributed solely to scheduling delay from these data. Its underlying cause remains unresolved.

## Artifact provenance and integrity

| Evidence | GitHub artifact | ZIP SHA-256 |
| --- | --- | --- |
| Old macOS failure | [11784166735](https://github.com/raven-deadwire/SpectralForge-Chimera-Amp-Matrix/actions/runs/38333154140/artifacts/11784166735) | `a5e826320ca33445113ca910921244685a78ef0e95f9d15e9e180160fef8f137` |
| Fresh Windows | [11785215523](https://github.com/raven-deadwire/SpectralForge-Chimera-Amp-Matrix/actions/runs/38335147293/artifacts/11785215523) | `bfd9e8ad74af48ac1469d666cef2027fcdb9002a2d3eb90ceea0628122a37b6e` |
| Fresh Linux | [11785221248](https://github.com/raven-deadwire/SpectralForge-Chimera-Amp-Matrix/actions/runs/38335147293/artifacts/11785221248) | `27741cafb72997cba7c842546ab663ce9ee7e9abf1648418b3577de2ba3774c2` |
| Fresh macOS | [11784824473](https://github.com/raven-deadwire/SpectralForge-Chimera-Amp-Matrix/actions/runs/38335147293/artifacts/11784824473) | `ae70b4ad96de306f524beba0977f7fab218c176d38e1d3ec0770a52b9c25ac57` |

Every downloaded ZIP matches the digest returned by GitHub. All 107 indexed evidence files within each of the four original archives were checked for exact size and SHA-256. Candidate source, tree, clean status, run ID, and attempt were verified from the fresh manifests. Original complete ZIPs remain local; this durable subset avoids duplicating the archives.

Each evidence directory contains original, unmodified `manifest.json`, `summary.md`, `SHA256SUMS.json`, candidate JUnit, and the 1,600-row raw CSV for the previously failing route. The original archive SHA index intentionally includes additional files that are retained in the full ZIP and are not copied into this subset. `verification-summary.json` is the derived inspection record. Top-level `github-artifact-metadata.json` preserves public GitHub artifact metadata; `verification.json` records the combined fresh result. Top-level `durable-SHA256SUMS.json` indexes only files actually present in this durable subset.
