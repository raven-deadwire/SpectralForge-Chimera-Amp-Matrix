# CAB realtime performance

Result: **PASS**

Candidate: `c3e9d436fbdc9b8778b592f333c93037b012b8c5`
Baseline: `aaa1330dd5cf7d51faf1c45a7cef633b9b118458`

Both revisions run sequentially on this runner, in separate Release builds.
The baseline is a measured reference. Candidate CTest and its unchanged p99 deadlines determine acceptance.

| Evidence | Complete | CTest exit | Deadline routes passing |
|---|---|---:|---:|
| Baseline | True | 8 | 35/36 |
| Candidate | True | 0 | 66/66 |

Instrumented diagnostic: complete=True, exit=0. Its timing does not replace CTest acceptance.

## Same-runner 96 kHz / 64-sample comparison

| Engine | Channels | Baseline p99 µs | Candidate p99 µs | Deadline µs | Baseline / candidate misses |
|---|---:|---:|---:|---:|---|
| original-v1 | 1 | 719.000 | 125.208 | 666.667 | 19/1600 / 0/1600 |
| original-v1 | 2 | 490.459 | 227.791 | 666.667 | 8/1600 / 1/1600 |
| expanded-v2 | 1 | 318.125 | 152.250 | 666.667 | 4/1600 / 0/1600 |
| expanded-v2 | 2 | 310.583 | 276.708 | 666.667 | 2/1600 / 6/1600 |
| array-v3-6x10 | 1 | 323.292 | 149.708 | 666.667 | 3/1600 / 3/1600 |
| array-v3-6x10 | 2 | 280.084 | 367.750 | 666.667 | 5/1600 / 8/1600 |

Complete route/phase/profile tables, all candidate and diagnostic callback CSVs, full logs, compiler configuration, source/tree SHAs and file hashes are in the artifact.
Raw wall time and CPU clocks are paired by callback index. Windows cycles remain cycles; they are not elapsed microseconds or a scheduling-only diagnosis.
