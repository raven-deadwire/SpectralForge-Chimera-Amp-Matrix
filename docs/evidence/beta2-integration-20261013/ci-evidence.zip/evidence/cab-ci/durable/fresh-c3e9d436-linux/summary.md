# CAB realtime performance

Result: **PASS**

Candidate: `c3e9d436fbdc9b8778b592f333c93037b012b8c5`
Baseline: `aaa1330dd5cf7d51faf1c45a7cef633b9b118458`

Both revisions run sequentially on this runner, in separate Release builds.
The baseline is a measured reference. Candidate CTest and its unchanged p99 deadlines determine acceptance.

| Evidence | Complete | CTest exit | Deadline routes passing |
|---|---|---:|---:|
| Baseline | True | 0 | 36/36 |
| Candidate | True | 0 | 66/66 |

Instrumented diagnostic: complete=True, exit=0. Its timing does not replace CTest acceptance.

## Same-runner 96 kHz / 64-sample comparison

| Engine | Channels | Baseline p99 µs | Candidate p99 µs | Deadline µs | Baseline / candidate misses |
|---|---:|---:|---:|---:|---|
| original-v1 | 1 | 171.389 | 150.157 | 666.667 | 0/1600 / 0/1600 |
| original-v1 | 2 | 179.231 | 164.669 | 666.667 | 0/1600 / 0/1600 |
| expanded-v2 | 1 | 186.212 | 150.889 | 666.667 | 0/1600 / 0/1600 |
| expanded-v2 | 2 | 182.276 | 171.870 | 666.667 | 0/1600 / 0/1600 |
| array-v3-6x10 | 1 | 165.229 | 218.901 | 666.667 | 0/1600 / 2/1600 |
| array-v3-6x10 | 2 | 174.313 | 170.087 | 666.667 | 0/1600 / 0/1600 |

Complete route/phase/profile tables, all candidate and diagnostic callback CSVs, full logs, compiler configuration, source/tree SHAs and file hashes are in the artifact.
Raw wall time and CPU clocks are paired by callback index. Windows cycles remain cycles; they are not elapsed microseconds or a scheduling-only diagnosis.
