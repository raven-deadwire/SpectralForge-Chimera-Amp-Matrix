#!/usr/bin/env python3
"""Read-only verification of recorded, unmodified GitHub API responses.

Invokes only the unchanged production verify_ci function. This is neither a
live publisher invocation nor a release/publication approval. Artifact bytes
and gate contents require separate verification.
"""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT=Path('/workspace/scratch/b934cbc39d7c/chimera-integration')
HERE=Path(__file__).resolve().parent
SOURCE='c3e9d436fbdc9b8778b592f333c93037b012b8c5'
sys.path.insert(0,str(ROOT/'Tools'))
import publish_release

def sha(data): return hashlib.sha256(data).hexdigest()
def git(*args): return subprocess.check_output(['git','-C',str(ROOT),*args],text=True).strip()

class RecordedAPI:
    def __init__(self,index):
        self.index=index
        self.calls=[]
    def pages(self,endpoint,key):
        entry=self.index['endpoints'][endpoint]
        raw=(HERE/entry['file']).read_bytes()
        if sha(raw)!=entry['sha256']:
            raise RuntimeError('Recorded API response hash mismatch: '+endpoint)
        data=json.loads(raw)
        values=data[key]
        if data['total_count']!=len(values):
            raise RuntimeError('Recorded pagination incomplete: '+endpoint)
        if "workflow_path" in entry:
            values=[r for r in values if r["path"]==entry["workflow_path"]]
        self.calls.append({'endpoint':endpoint,'key':key,'file':entry['file'],
                           'sha256':entry['sha256'],'records':len(values)})
        return values

def main():
    if git('rev-parse','HEAD')!=SOURCE or git('status','--porcelain','--untracked-files=no'):
        raise RuntimeError('Production checkout must be clean and match the frozen source')
    index=json.loads((HERE/'verify-ci-api-index.json').read_text())
    if index['source_sha']!=SOURCE:
        raise RuntimeError('Recorded API index source mismatch')
    api=RecordedAPI(index)
    try:
        ci=publish_release.verify_ci(api,publish_release.Release('1.3.1-beta.2',SOURCE))
    except Exception as exc:
        result={'schema':'chimera.recorded-ci-metadata-verification.v1','result':'REJECTED',
                'source_sha':SOURCE,'release_version':'1.3.1-beta.2',
                'scope':'Recorded actual API metadata with locally filtered workflow paths; unchanged production verify_ci invocation, not publication or approval.',
                'exception_type':type(exc).__name__,'reason':str(exc),
                'required_workflow_count':len(publish_release.WORKFLOWS),
                'required_job_count':sum(len(v) for v in publish_release.WORKFLOWS.values()),
                'production_verifier_sha256':sha((ROOT/'Tools/publish_release.py').read_bytes()),
                'production_helpers_sha256':sha((ROOT/'Tools/publish_beta131.py').read_bytes()),
                'api_calls':api.calls}
        (HERE/'recorded-ci-metadata-verification.json').write_text(json.dumps(result,indent=2)+'\n')
        print(json.dumps(result,indent=2))
        return 1
    result={'schema':'chimera.recorded-ci-metadata-verification.v1','result':'PASS',
            'source_sha':SOURCE,'release_version':'1.3.1-beta.2',
            'scope':'Recorded API metadata verification using unchanged Tools/publish_release.py verify_ci; not a live publisher invocation, artifact-byte verification, release approval or publication.',
            'required_workflow_count':len(publish_release.WORKFLOWS),
            'required_job_count':sum(len(v) for v in publish_release.WORKFLOWS.values()),
            'production_verifier_sha256':sha((ROOT/'Tools/publish_release.py').read_bytes()),
            'production_helpers_sha256':sha((ROOT/'Tools/publish_beta131.py').read_bytes()),
            'api_calls':api.calls,
            'verified_runs':{k:{'id':r['id'],'head_sha':r['head_sha'],'run_attempt':r['run_attempt'],
                                'status':r['status'],'conclusion':r['conclusion'],'url':r['html_url']}
                             for k,r in ci['runs'].items()},
            'candidate_artifact':ci['candidate'],'gate_artifact':ci['gate']}
    (HERE/'recorded-ci-metadata-verification.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ('result','source_sha','scope','required_workflow_count','required_job_count')},indent=2))
    return 0
if __name__=='__main__': raise SystemExit(main())
