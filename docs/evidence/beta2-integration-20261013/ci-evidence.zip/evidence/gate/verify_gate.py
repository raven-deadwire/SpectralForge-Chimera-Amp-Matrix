#!/usr/bin/env python3
"""Verify a newly downloaded original CI gate with the unchanged publisher.

No evidence is generated or substituted. This never invokes publication.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile


REPO = None
SOURCE = None
RUN = None
ATTEMPT = None


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO, text=True).strip()


def source_clean():
    assert git('rev-parse', 'HEAD') == SOURCE, 'Current source differs from selected source'
    assert not git('status', '--porcelain=v1'), 'Current source is dirty'


def file_sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    global REPO, SOURCE, RUN, ATTEMPT
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--source-sha', required=True)
    parser.add_argument('--run-id', type=int, required=True)
    parser.add_argument('--run-attempt', type=int, default=1)
    parser.add_argument('--archive', type=Path, required=True)
    parser.add_argument('--artifact-json', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    REPO = args.repo.resolve()
    SOURCE = args.source_sha
    RUN = args.run_id
    ATTEMPT = args.run_attempt
    source_clean()
    sys.path.insert(0, str(REPO / 'Tools'))
    import publish_release as publisher

    raw = publisher.read_json(args.artifact_json)
    records = raw['artifacts'] if isinstance(raw, dict) and 'artifacts' in raw else [raw]
    artifact = publisher.verified_artifact(records, publisher.GATE_ARTIFACT_NAME, SOURCE, RUN)
    archive_sha = file_sha(args.archive)
    assert args.archive.stat().st_size == artifact['size_in_bytes'], 'Archive size mismatch'
    assert 'sha256:' + archive_sha == artifact['digest'], 'Archive SHA-256 mismatch'
    args.output.mkdir(parents=True, exist_ok=True)
    command = [sys.executable, 'Tools/publish_release.py', '--dry-run',
               '--target-version', '1.3.1-beta.2', '--source-sha', SOURCE,
               '--gate-archive', str(args.archive), '--run-id', str(RUN),
               '--run-attempt', str(ATTEMPT)]
    log = args.output / 'publisher-with-actual-gate-dry-run.json'
    with log.open('w') as stream:
        result = subprocess.run(command, cwd=REPO, stdout=stream, stderr=subprocess.STDOUT)
    assert result.returncode == 0, 'Existing publisher rejected the gate; inspect preserved log'
    dry_run = json.loads(log.read_text())
    assert dry_run['source_sha'] == SOURCE and dry_run['published'] is False
    assert dry_run['publication_ready'] is False and dry_run['candidate'] == 'NOT_SUPPLIED'
    assert file_sha(args.archive) == archive_sha, 'Archive changed during verification'
    with zipfile.ZipFile(args.archive) as bundle:
        gate_names = [n for n in bundle.namelist() if Path(n).name == 'release-gate.json']
        assert len(gate_names) == 1
        original_gate = bundle.read(gate_names[0])
        verdict = json.loads(original_gate.decode('utf-8-sig'))
        entry_count = len(bundle.infolist())
    assert verdict['revision'] == {'commit_sha': SOURCE, 'run_id': str(RUN),
                                    'run_attempt': str(ATTEMPT)}
    assert dry_run['consolidated_acceptance'] == verdict['verdict']
    gate_file = args.output / 'verified-original-release-gate.json'
    gate_file.write_bytes(original_gate)
    source_clean()
    summary = {
        'source_sha': SOURCE, 'source_tree': git('rev-parse', 'HEAD^{tree}'),
        'repository_path': str(REPO), 'runner_file_sha256': file_sha(Path(__file__)),
        'verified_at_utc': datetime.now(timezone.utc).isoformat(),
        'run_id': RUN, 'run_attempt': ATTEMPT,
        'artifact': artifact, 'archive_path': str(args.archive),
        'archive_size_verified': artifact['size_in_bytes'], 'archive_sha256_verified': archive_sha,
        'original_metadata_file': str(args.artifact_json),
        'original_metadata_sha256': file_sha(args.artifact_json),
        'archive_entries': entry_count, 'existing_publisher_exit_code': result.returncode,
        'existing_publisher_command': command,
        'verified_gate_path': str(gate_file), 'verified_gate_sha256': file_sha(gate_file),
        'gate_profile': verdict['profile'], 'gate_verdict': verdict['verdict'],
        'gate_ready': verdict['ready'], 'counts': verdict['counts'],
        'hard_gates': verdict['hard_gates'],
        'embedded_original_platform_bundles': len(verdict['producer']['inputs']),
        'producer_errors': verdict['producer']['errors'], 'publisher_dry_run': dry_run,
        'source_clean_after': True, 'older_source_evidence_reused': False,
        'scope': 'Original gate archive integrity, exact source/run identity, underlying checks, and embedded raw evidence reverified by the unchanged source publisher. No candidate binary archive or live CI verification is supplied to this offline invocation.',
    }
    (args.output / 'gate-verification-summary.json').write_text(
        json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: summary[k] for k in ('source_sha', 'run_id', 'run_attempt',
        'archive_size_verified', 'archive_sha256_verified', 'existing_publisher_exit_code',
        'gate_verdict', 'gate_ready', 'counts', 'hard_gates',
        'embedded_original_platform_bundles', 'producer_errors', 'source_clean_after')}, indent=2))


if __name__ == '__main__':
    main()
