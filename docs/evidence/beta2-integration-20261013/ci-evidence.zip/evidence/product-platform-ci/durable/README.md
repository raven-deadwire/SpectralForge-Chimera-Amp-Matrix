# Exact-source macOS and Linux Product CI evidence

Tested product source: `c3e9d436fbdc9b8778b592f333c93037b012b8c5` (`1.3.1-beta.2`). Original [Product workflow run 38335147294](https://github.com/raven-deadwire/SpectralForge-Chimera-Amp-Matrix/actions/runs/38335147294), attempt 1. This evidence records the two completed platform jobs; it does not assert the consolidated release gate or release approval. Product source and release policy remain unchanged.

## Results and verification

| Platform | Original completed job | Fresh CTest result | Wall time | Release-evidence artifact |
|---|---|---|---|---|
| macOS | [115095947688](https://github.com/raven-deadwire/SpectralForge-Chimera-Amp-Matrix/actions/runs/38335147294/job/115095947688), success | 44/44, zero failures/skips | 865.49 s | 11786669782, 57,403 bytes |
| Linux | [115095947764](https://github.com/raven-deadwire/SpectralForge-Chimera-Amp-Matrix/actions/runs/38335147294/job/115095947764), success | 45/45, zero failures/skips | 972.46 s | 11786128200, 58,557 bytes |

The JUnit names match the complete configured CTest inventories on each platform. Linux has the additional `ChimeraNativeFocusTests`. The Linux workflow executes CTest through its display supervision wrapper; these are CI results independent of the separately documented local Xvfb failure. Neither these results nor the source identity are reused from an earlier commit.

Both downloaded evidence ZIPs match GitHub's original sizes and SHA-256 digests, pass ZIP CRC checks, and have valid hashes for all four files referenced by each original `evidence.json`. Artifact metadata, internal revision (`commit_sha`, `run_id`, `run_attempt`), and the original checkout log agree. Digests:

- macOS: `07e7dcda1095bfdbeee921125541c870c1a9ac35e6d155bd20d13af5a151c51f`
- Linux: `0f7b2d186ecbd8de305201179ac71d1808a90e2212dea53b50bd62c880c4e59d`

## Packaging compatibility actually checked

**macOS:** built Standalone, VST3, and AU bundle executables contain arm64 and x86_64 slices. The document maintenance helper also has both slices. Staged bundles and helper receive ad-hoc signatures and pass strict code-seal checks; this establishes no Developer ID identity or notarization. The standalone microphone usage description is checked. Fixed system destinations are staged and component relocatability is disabled. `pkgbuild` produces the package with native preinstall/postinstall hooks; `pkgutil --expand-full` extracts it, and all three product executables plus both lifecycle hooks are compared against staged byte hashes. The offline manual and document payload are staged. The package receives a checksum.

**Linux:** built x86_64 Standalone, VST3, document maintenance helper, desktop entry, artwork, and documents are staged. `dpkg-shlibdeps` derives explicit runtime dependencies; the maintenance helper's `Pre-Depends` is independently derived (`libc6 >= 2.34`). Product dependencies include `libc6 >= 2.35` and `libstdc++6 >= 12`; the original report preserves the full list. Native preinst/postinst/prerm/postrm hooks are packaged. `dpkg-deb --extract` is followed by SHA-256 comparison of Standalone, VST3 binary, and manual. `ldd` finds no unresolved Standalone/VST3 libraries on the Ubuntu 22.04 builder. A portable tar.gz is constructed from the verified stage, with `install.sh`, installation documentation, and explicit runtime dependency metadata. DEB and tar.gz checksums are generated. This Product packaging path does not independently re-extract or install the tar.gz.

These conclusions combine the original package reports and job success with the preserved packaging script at the exact tested source. The large platform binary ZIPs were not downloaded for this audit.

## Acceptance scope remaining

The generated macOS PKG and Linux DEB/tar.gz were **not installed as products** by these two Product jobs. They do not execute a previous-release-to-current full-product upgrade, launch the installed Standalone for user acceptance, load the installed plug-in in a real DAW, certify real hardware audio/listening, or establish cross-distribution compatibility. macOS Developer ID signing and notarization are also not certified. Native/unit/integration CTests do execute product code, but are not installed-product acceptance.

Separate document upgrade fixture tests and separate Windows installer evidence have their own scopes; they do not expand the scope of these macOS/Linux package checks. The `installer: skipped`, `msix: skipped`, and `scan: skipped` fields in these platform evidence files refer to Windows-only Product workflow steps. They must not be represented as macOS/Linux installed-product PASS.

## Files

Original API artifact/job metadata, each platform's unmodified `evidence.json`, JUnit, inventory, `LastTest.log`, package report, and selected original checkout/CTest/package job log lines are retained. `verification.json` binds the full original job log hashes, source, run, and artifact identities. `source/` preserves the exact source used to interpret check coverage. `durable-file-index.json` hashes the compact bundle. Full original job logs and ZIPs remain in the surrounding local evidence workspace; no transfer credentials or helpers are included here.
