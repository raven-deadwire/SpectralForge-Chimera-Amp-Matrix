from pathlib import Path
import datetime, hashlib, json, zipfile

ROOT = Path('/workspace/scratch/b934cbc39d7c')
EVIDENCE = ROOT / 'evidence'
OUT = ROOT / 'verification-delivery'
SOURCE = 'c3e9d436fbdc9b8778b592f333c93037b012b8c5'

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

files = []
# Deliberate allow-list: original report files and summaries, never transport credentials.
for name in ['verification-complete.json', 'workflow-complete.json',
             'jobs-complete.json', 'artifacts-complete.json',
             '11784981306.zip', '11785230589.zip', '11785491580.zip']:
    files.append(EVIDENCE / 'installer-ci' / name)
files.extend((EVIDENCE / 'cab-ci' / 'durable').rglob('*'))

# The final selection is supplied after all original CI responses and artifacts exist.
selection = json.loads((ROOT / 'final-ci-evidence-selection.json').read_text())
assert selection['source_sha'] == SOURCE
for relative in selection['files']:
    path = ROOT / relative
    assert path.resolve().is_relative_to(EVIDENCE.resolve())
    assert not any(part.startswith('transfer') for part in path.parts)
    files.append(path)
files.append(Path(__file__).resolve())
files = sorted(set(path for path in files if path.is_file()))

manifest = {
    'schema': 'chimera.integrated-beta2-ci-evidence.v1',
    'source_sha': SOURCE,
    'source_tree': '9f147ca042491a56af6373592707bf2f6179b4c1',
    'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'evidence_only': True,
    'older_source_pass_reused': False,
    'historical_failure_included_for_traceability': '022244e6ce845669665e9ffdfefe25bdee154b75',
    'publication_authorized': False,
    'selection': selection,
    'files': [],
}

OUT.mkdir(exist_ok=True)
with zipfile.ZipFile(OUT / 'ci-evidence.zip', 'w', compression=zipfile.ZIP_DEFLATED,
                     compresslevel=9) as bundle:
    for path in files:
        raw = path.read_bytes()
        name = str(path.relative_to(ROOT))
        manifest['files'].append({'path': name, 'bytes': len(raw), 'sha256': digest(raw)})
        bundle.writestr(name, raw)
    bundle.writestr('ci-evidence-manifest.json', json.dumps(manifest, indent=2) + '\n')
raw = (OUT / 'ci-evidence.zip').read_bytes()
manifest['archive'] = {'filename': 'ci-evidence.zip', 'bytes': len(raw), 'sha256': digest(raw)}
(OUT / 'ci-evidence-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'source_sha': SOURCE, 'files': len(files), 'archive': manifest['archive']}, indent=2))
