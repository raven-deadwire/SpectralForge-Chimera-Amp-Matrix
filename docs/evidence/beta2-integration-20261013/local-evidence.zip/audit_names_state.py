#!/usr/bin/env python3
"""Read-only static integration audit; regenerate catalogs only in a temp tree."""
import hashlib, json, pathlib, re, shutil, subprocess, tempfile, sys

ROOT=pathlib.Path('/workspace/scratch/b934cbc39d7c/chimera-integration')
OUT=pathlib.Path('/workspace/scratch/b934cbc39d7c/evidence/names-state')
BASE55='022244e6ce845669665e9ffdfefe25bdee154b75'
DONOR56='d7450883ddbeba58e44cf217072f325654c16128'
COMMON='559d0cb4aa0fa70ababdb1f29b71ea022a27bc4c'
def git(*args): return subprocess.check_output(['git','-C',str(ROOT),*args])
def blob(ref,path): return git('show',f'{ref}:{path}')
def sha(data): return hashlib.sha256(data).hexdigest()
def names(ref1,ref2,*paths): return git('diff','--name-only',ref1,ref2,'--',*paths).decode().splitlines()
LEX=re.compile(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|//[^\n]*|/\*[\s\S]*?\*/')
def cpp_canonical(data, mask_strings=False):
    def sub(m):
        s=m.group()
        if s.startswith('//') or s.startswith('/*'): return ''
        return '"TEXT"' if mask_strings and s.startswith('"') else s
    return re.sub(r'\s+',' ',LEX.sub(sub,data.decode())).strip()

def main():
    head=git('rev-parse','HEAD').decode().strip()
    if len(sys.argv)>1 and head!=sys.argv[1]: raise RuntimeError('HEAD does not match requested frozen SHA')
    donor58=git('rev-parse','068f1547').decode().strip()
    report={'source_sha':head,'baseline_55':BASE55,'donor_56':DONOR56,'donor_58':donor58,
            'scope':'Static compatibility and reproducibility; does not replace native build, host or installer acceptance',
            'checks':[]}
    def check(label,ok,**details):
        report['checks'].append({'check':label,'result':'PASS' if ok else 'FAIL',**details})
    source_paths=git('ls-tree','-r','--name-only',BASE55,'Source').decode().splitlines()
    donor_changed=set(names(COMMON,DONOR56,'Source'))
    final_changed=set(names(BASE55,head,'Source'))
    check('Integration source changes stay within reviewed naming donor',final_changed==donor_changed,
          changed=sorted(final_changed),unexpected=sorted(final_changed-donor_changed))
    unchanged=[p for p in source_paths if p not in donor_changed]
    mismatches=[p for p in unchanged if blob(BASE55,p)!=blob(head,p)]
    check('All other production Source files byte-identical to latest #55',not mismatches,
          files_checked=len(unchanged),mismatches=mismatches)
    # Only these three source files also carry the latest Niflheimr display rename.
    overlap={'Source/FactoryCabVoicing.h','Source/FactoryPresetLevels.h','Source/NiflheimrPresets.h'}
    mismatches=[p for p in sorted(donor_changed-overlap) if blob(DONOR56,p)!=blob(head,p)]
    check('Other reviewed naming source files preserved byte-for-byte',not mismatches,
          files_checked=len(donor_changed-overlap),mismatches=mismatches)
    for path in ['Source/FactoryCabVoicing.h','Source/FactoryNativeVoicing.h','Source/FactoryPresetLevels.h',
                 'Source/AmpHeadShellMetadata.h','Source/CabHeadDimensions.h']:
        check(path+' executable data unchanged',cpp_canonical(blob(BASE55,path))==cpp_canonical(blob(head,path)))
    # Structural token equality checks numeric defaults/ranges, control order,
    # routing recipes and logic. Identity literals are checked separately below.
    for path in ['Source/AmpNativeCatalog.h','Source/AmpHeadLayout.h','Source/PedalBoardCatalog.h',
                 'Source/FactoryPresets.h','Source/GuitarSignaturePresets.h','Source/OriginalPresets.h',
                 'Source/NiflheimrPresets.h','Source/ModelCatalog.h']:
        check(path+' non-display structure unchanged',cpp_canonical(blob(BASE55,path),True)==cpp_canonical(blob(head,path),True))
    identities=re.compile(r'"((?:hw\.|legacy\.|planned\.|pre\.mod\.|original\.rig\.|raven\.)[^"\\]*)"')
    id_paths=['Source/AmpNativeCatalog.h','Source/AmpHeadLayout.h','Source/PedalBoardCatalog.h',
              'Source/GuitarSignaturePresets.h','Source/OriginalPresets.h','Source/NiflheimrPresets.h']
    for path in id_paths:
        before=identities.findall(blob(BASE55,path).decode()); after=identities.findall(blob(head,path).decode())
        check(path+' serialized/control identity sequence unchanged',before==after,identities_checked=len(before))
    for path,pattern in [
            ('Source/PedalBoardCatalog.h',r'\{"([^"\\]+)","(?:\\.|[^"\\])*",[-+.\d]'),
            ('Source/FactoryPresets.h',r'\{"([^"\\]+)",(-?[\d.]+f?)\}'),
            ('Source/ModelCatalog.h',r'\{"([^"\\]+)","[^"\\]+",\d+,\{\{')]:
        before=re.findall(pattern,blob(BASE55,path).decode());after=re.findall(pattern,blob(head,path).decode())
        check(path+' all parameter/control keys and numeric mappings unchanged',bool(before) and before==after,records_checked=len(before))
    # Factory snapshot bodies, including all parameter IDs, are exact source matches.
    for path,marker in [('Source/NiflheimrPresets.h','inline constexpr int niflheimrPresetCount'),
                        ('Source/OriginalPresets.h','inline constexpr int originalPresetCount'),
                        ('Source/GuitarSignaturePresets.h','inline constexpr int selectablePresetCount')]:
        a=blob(BASE55,path).decode(); b=blob(head,path).decode()
        check(path+' complete recall implementation unchanged',marker in a and marker in b and a[a.index(marker):]==b[b.index(marker):])
    nifl=blob(head,'Source/NiflheimrPresets.h').decode()
    rows=re.findall(r'\{"(original\.rig\.niflheimr\.[^"]+)","([^"]+)","([^"]+)","([^"]+)",(\d+)\}',nifl)
    check('Niflheimr final labels, exported filenames, routing and Optical description retained',
          len(rows)==5 and [r[1] for r in rows]==['Metal Clank','Death Grind','Heavy Pulse','Slam Punch','Doom Fuzz']
          and [r[4] for r in rows]==['0','1','2','2','0']
          and rows[0][3]=='Niflheimr-01-Metal-Clank.chimera' and rows[2][3]=='Niflheimr-03-Heavy-Pulse.chimera'
          and 'gentle Optical compression' in rows[4][2],rows=rows)
    # Exact previous POST implementation remains; donor only adds its caption helper.
    before=blob(BASE55,'Source/PostNativeCatalog.h').decode().replace('} // namespace spectralforge','').rstrip()
    after=blob(head,'Source/PostNativeCatalog.h').decode().split('inline const char* postNativeDescription')[0].rstrip()
    check('POST native parameters, defaults, IDs and state unchanged',before==after)
    policies=['Validation/release-policy.json','Validation/weekly-publication-policy.json',
              'Validation/beta-publication-policy-1.3.1.json','Validation/beta-publication-policy.json',
              'Validation/waivers.json','Tools/weekly_publication.py','Tools/evaluate_release_gate.py',
              'Tools/release_evidence.py','Tools/consolidate_release_gate.py','Tools/verify_publication_evidence.py',
              '.github/workflows/release-publisher.yml','.github/workflows/prepare-release.yml']
    for path in policies:
        check(path+' approval policy unchanged',blob(BASE55,path)==blob(head,path))
    # The integration importer contains verified donor tip trees; some interim
    # #58 ancestor trees are deliberately absent. Compare the full #56/#58 tips.
    cleanup_paths=names(DONOR56,donor58)
    production=[p for p in cleanup_paths if p.startswith(('Installer/','Tools/','Validation/')) and not pathlib.Path(p).name.startswith('test_')]
    for path in production: check(path+' #58 production/inventory preserved',blob(donor58,path)==blob(head,path))
    with tempfile.TemporaryDirectory(prefix='chimera-catalog-audit-') as raw:
        temp=pathlib.Path(raw); (temp/'Source').mkdir();(temp/'Tools').mkdir()
        shutil.copytree(ROOT/'Preparation',temp/'Preparation')
        for script,output in [('generate_amp_native_catalog.py','AmpNativeCatalog.h'),
                              ('generate_pedal_catalog.py','PedalBoardCatalog.h'),
                              ('generate_post_native_catalog.py','PostNativeCatalog.h')]:
            (temp/'Tools'/script).write_bytes(blob(head,'Tools/'+script))
            result=subprocess.run([sys.executable,str(temp/'Tools'/script)],cwd=temp,capture_output=True,text=True)
            generated=(temp/'Source'/output).read_bytes() if (temp/'Source'/output).exists() else b''
            expected=blob(head,'Source/'+output)
            check(script+' reproduces committed catalog',result.returncode==0 and generated==expected,
                  generated_sha256=sha(generated),committed_sha256=sha(expected),stderr=result.stderr)
    suite=subprocess.run([sys.executable,'Tests/test_public_names.py'],cwd=ROOT,capture_output=True,text=True)
    check('Fresh public-name Python unit suite',suite.returncode==0,returncode=suite.returncode,
          stdout=suite.stdout,stderr=suite.stderr)
    check('Audit ran against unchanged frozen checkout',git('rev-parse','HEAD').decode().strip()==head
          and not git('status','--porcelain','--untracked-files=no').decode().strip())
    report['passed']=sum(x['result']=='PASS' for x in report['checks'])
    report['failed']=sum(x['result']=='FAIL' for x in report['checks'])
    OUT.mkdir(parents=True,exist_ok=True)
    (OUT/'static-compatibility.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(report,ensure_ascii=False,indent=2))
    return int(report['failed']>0)
if __name__=='__main__': raise SystemExit(main())
