python -m py_compile Tools/check_catalog_contract.py Tools/check_ci_validation_map.py Tools/produce_validation_check.py Tools/test_validation_producer.py Tools/seed_validation_reports.py Tools/evaluate_release_gate.py Tools/analyze_callback_pairs.py Tools/run_paired_callback_probe.py Tools/test_callback_timing_protocol.py Tools/release_evidence.py Tools/produce_release_evidence.py Tools/consolidate_release_gate.py Tools/check_ir_distribution.py Tests/test_ir_distribution.py
python Tools/check_catalog_contract.py
python Tools/check_ir_distribution.py
python Tests/test_ir_distribution.py
python Tools/check_ci_validation_map.py
python Tools/test_validation_producer.py
python Tools/test_ctest_validation.py
python Tools/test_release_consolidator.py
python Tools/test_publish_beta112.py
python Tools/test_publish_beta12.py
python Tools/test_publish_beta13.py
python Tools/test_beta_publication.py
python Tools/test_publish_beta131.py
python Tools/test_beta_publication131.py
python Tools/test_publish_release.py
python Tools/test_weekly_publication.py
python Tools/test_publication_evidence.py
python Tests/test_packaging_version.py
python Tools/test_release_preflight.py
python Tools/test_callback_timing_protocol.py
python Tools/seed_validation_reports.py --commit "c3e9d436fbdc9b8778b592f333c93037b012b8c5" --profile pull_request --output /workspace/scratch/b934cbc39d7c/evidence/source-contracts-final/validation
