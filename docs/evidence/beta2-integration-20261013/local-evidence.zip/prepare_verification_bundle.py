from pathlib import Path
import hashlib,json,subprocess,zipfile,datetime
root=Path('/workspace/scratch/b934cbc39d7c');repo=root/'chimera-integration';ev=root/'evidence';out=root/'verification-delivery';out.mkdir(exist_ok=True)
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert sha=='c3e9d436fbdc9b8778b592f333c93037b012b8c5'
assert not subprocess.check_output(['git','status','--porcelain=v1'],cwd=repo,text=True).strip()
files=[]
for group in ['source-contracts-final','installer','names-state']:
    files.extend(x for x in (ev/group).iterdir() if x.is_file())
files += [ev/'source-contracts'/'validation-contract.log',ev/'source-contracts'/'source-contract-results.json']
for name in ['native-result.json','identity.json','configure.log','build-attempt1.log','build-attempt2.log','environment-repair.json','ctest-requested.log','ctest-processor-state.log','ctest-processor-state.xml','test-execution.json','test-processor-state-execution.json','requested-test-inventory.json','chimera-build-version.json','BinaryData209.cpp.o.invalid-zero-byte']:
    files.append(ev/'native'/name)
files += list((ev/'native'/'native-state').rglob('*.json'))
files += list((ev/'native'/'niflheimr-preset-evidence').rglob('*.json'))
files.extend([root/'audit_names_state.py',root/'prepare_verification_bundle.py'])
manifest={'schema':'chimera.integrated-beta2-local-evidence.v1','source_sha':sha,'source_tree':'9f147ca042491a56af6373592707bf2f6179b4c1','parents':['022244e6ce845669665e9ffdfefe25bdee154b75','068f1547face75b34c1760dd7b8c9d34868a5393'],'included_pr56':'d7450883ddbeba58e44cf217072f325654c16128','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'production_source_changed_during_validation':False,'older_source_pass_reused':False,'files':[]}
with zipfile.ZipFile(out/'local-evidence.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for path in sorted(set(files)):
        raw=path.read_bytes();name=str(path.relative_to(root))
        manifest['files'].append({'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()});archive.writestr(name,raw)
    archive.writestr('evidence-manifest.json',json.dumps(manifest,indent=2)+'\n')
raw=(out/'local-evidence.zip').read_bytes();manifest['archive']={'filename':'local-evidence.zip','bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
(out/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for src,name in [('source-contracts-final/source-contract-results.json','source-contract-results.json'),('names-state/static-compatibility.json','static-compatibility.json'),('installer/suite-results.json','installer-suite-results.json'),('installer/current-documents-results.json','current-documents-results.json'),('native/native-result.json','native-result.json'),('native/ctest-processor-state.xml','ctest-processor-state.xml')]:
    (out/name).write_bytes((ev/src).read_bytes())
print(json.dumps({'source_sha':sha,'files':len(manifest['files']),'archive':manifest['archive'],'directory':str(out)},indent=2))
