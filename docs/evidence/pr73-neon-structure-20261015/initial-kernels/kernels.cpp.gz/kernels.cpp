#include <arm_neon.h>
extern "C" __attribute__((noinline)) void scalar(const float* __restrict input,const float* __restrict impulse,float* __restrict output,int bins) noexcept {
        int i=0;
#if defined(_MSC_VER) && (defined(_M_X64) || defined(_M_IX86))
        // Native Windows profiling identified sustained spectral-MAC cost in
        // this loop. Make its four-float SIMD work explicit on MSVC instead of
        // depending on auto-vectorization of the two variable-offset stores.
        // Mono has N/2+1 bins, so neither the imaginary plane nor every input
        // partition is SIMD-aligned. Unaligned loads/stores are intentional.
        for(;i+4<=bins;i+=4) {
            const auto inputReal=_mm_loadu_ps(input+i);
            const auto inputImag=_mm_loadu_ps(input+bins+i);
            const auto impulseReal=_mm_loadu_ps(impulse+i);
            const auto impulseImag=_mm_loadu_ps(impulse+bins+i);
            const auto outputReal=_mm_loadu_ps(output+i);
            const auto outputImag=_mm_loadu_ps(output+bins+i);
            const auto real=_mm_sub_ps(_mm_add_ps(outputReal,_mm_mul_ps(inputReal,impulseReal)),
                                      _mm_mul_ps(inputImag,impulseImag));
            const auto imag=_mm_add_ps(_mm_add_ps(outputImag,_mm_mul_ps(inputReal,impulseImag)),
                                      _mm_mul_ps(inputImag,impulseReal));
            _mm_storeu_ps(output+i,real);
            _mm_storeu_ps(output+bins+i,imag);
        }
#endif
        for(;i<bins;++i) {
            const float re=(output[i]+input[i]*impulse[i])-input[bins+i]*impulse[bins+i];
            const float im=(output[bins+i]+input[i]*impulse[bins+i])+input[bins+i]*impulse[i];
            output[i]=re;output[bins+i]=im;
        }
}
extern "C" __attribute__((noinline)) void neon4(const float* __restrict input,const float* __restrict impulse,float* __restrict output,int bins) noexcept {
        int i=0;
#if defined(_MSC_VER) && (defined(_M_X64) || defined(_M_IX86))
        // Native Windows profiling identified sustained spectral-MAC cost in
        // this loop. Make its four-float SIMD work explicit on MSVC instead of
        // depending on auto-vectorization of the two variable-offset stores.
        // Mono has N/2+1 bins, so neither the imaginary plane nor every input
        // partition is SIMD-aligned. Unaligned loads/stores are intentional.
        for(;i+4<=bins;i+=4) {
            const auto inputReal=_mm_loadu_ps(input+i);
            const auto inputImag=_mm_loadu_ps(input+bins+i);
            const auto impulseReal=_mm_loadu_ps(impulse+i);
            const auto impulseImag=_mm_loadu_ps(impulse+bins+i);
            const auto outputReal=_mm_loadu_ps(output+i);
            const auto outputImag=_mm_loadu_ps(output+bins+i);
            const auto real=_mm_sub_ps(_mm_add_ps(outputReal,_mm_mul_ps(inputReal,impulseReal)),
                                      _mm_mul_ps(inputImag,impulseImag));
            const auto imag=_mm_add_ps(_mm_add_ps(outputImag,_mm_mul_ps(inputReal,impulseImag)),
                                      _mm_mul_ps(inputImag,impulseReal));
            _mm_storeu_ps(output+i,real);
            _mm_storeu_ps(output+bins+i,imag);
        }
#elif defined(__APPLE__) && defined(__aarch64__)
        // The macOS attribution matrix places the 96 kHz / 32-sample cost in
        // this spectral MAC, while publication itself remains negligible.
        // AppleClang contracts the scalar multiply/add pairs on arm64. Express
        // the same two-step FMA/FMS arithmetic explicitly for four planar bins
        // so the frozen residue-bank output remains the compatibility gate.
        for(;i+4<=bins;i+=4) {
            const auto inputReal=vld1q_f32(input+i);
            const auto inputImag=vld1q_f32(input+bins+i);
            const auto impulseReal=vld1q_f32(impulse+i);
            const auto impulseImag=vld1q_f32(impulse+bins+i);
            const auto outputReal=vld1q_f32(output+i);
            const auto outputImag=vld1q_f32(output+bins+i);
            const auto real=vfmsq_f32(vfmaq_f32(outputReal,inputReal,impulseReal),
                                      inputImag,impulseImag);
            const auto imag=vfmaq_f32(vfmaq_f32(outputImag,inputReal,impulseImag),
                                      inputImag,impulseReal);
            vst1q_f32(output+i,real);
            vst1q_f32(output+bins+i,imag);
        }
#endif
        for(;i<bins;++i) {
            const float re=(output[i]+input[i]*impulse[i])-input[bins+i]*impulse[bins+i];
            const float im=(output[bins+i]+input[i]*impulse[bins+i])+input[bins+i]*impulse[i];
            output[i]=re;output[bins+i]=im;
        }
}
extern "C" __attribute__((noinline)) void neon8(const float* __restrict input,const float* __restrict impulse,float* __restrict output,int bins) noexcept {
        int i=0;
#if defined(_MSC_VER) && (defined(_M_X64) || defined(_M_IX86))
        // Native Windows profiling identified sustained spectral-MAC cost in
        // this loop. Make its four-float SIMD work explicit on MSVC instead of
        // depending on auto-vectorization of the two variable-offset stores.
        // Mono has N/2+1 bins, so neither the imaginary plane nor every input
        // partition is SIMD-aligned. Unaligned loads/stores are intentional.
        for(;i+4<=bins;i+=4) {
            const auto inputReal=_mm_loadu_ps(input+i);
            const auto inputImag=_mm_loadu_ps(input+bins+i);
            const auto impulseReal=_mm_loadu_ps(impulse+i);
            const auto impulseImag=_mm_loadu_ps(impulse+bins+i);
            const auto outputReal=_mm_loadu_ps(output+i);
            const auto outputImag=_mm_loadu_ps(output+bins+i);
            const auto real=_mm_sub_ps(_mm_add_ps(outputReal,_mm_mul_ps(inputReal,impulseReal)),
                                      _mm_mul_ps(inputImag,impulseImag));
            const auto imag=_mm_add_ps(_mm_add_ps(outputImag,_mm_mul_ps(inputReal,impulseImag)),
                                      _mm_mul_ps(inputImag,impulseReal));
            _mm_storeu_ps(output+i,real);
            _mm_storeu_ps(output+bins+i,imag);
        }
#elif defined(__APPLE__) && defined(__aarch64__)
        // The macOS attribution matrix places the 96 kHz / 32-sample cost in
        // this spectral MAC, while publication itself remains negligible.
        // AppleClang contracts the scalar multiply/add pairs on arm64. Express
        // the same two-step FMA/FMS arithmetic explicitly for four planar bins
        // so the frozen residue-bank output remains the compatibility gate.
        #pragma clang loop unroll_count(2)
        for(;i+4<=bins;i+=4) {
            const auto inputReal=vld1q_f32(input+i);
            const auto inputImag=vld1q_f32(input+bins+i);
            const auto impulseReal=vld1q_f32(impulse+i);
            const auto impulseImag=vld1q_f32(impulse+bins+i);
            const auto outputReal=vld1q_f32(output+i);
            const auto outputImag=vld1q_f32(output+bins+i);
            const auto real=vfmsq_f32(vfmaq_f32(outputReal,inputReal,impulseReal),
                                      inputImag,impulseImag);
            const auto imag=vfmaq_f32(vfmaq_f32(outputImag,inputReal,impulseImag),
                                      inputImag,impulseReal);
            vst1q_f32(output+i,real);
            vst1q_f32(output+bins+i,imag);
        }
#endif
        for(;i<bins;++i) {
            const float re=(output[i]+input[i]*impulse[i])-input[bins+i]*impulse[bins+i];
            const float im=(output[bins+i]+input[i]*impulse[bins+i])+input[bins+i]*impulse[i];
            output[i]=re;output[bins+i]=im;
        }
}
extern "C" __attribute__((noinline)) void neon16(const float* __restrict input,const float* __restrict impulse,float* __restrict output,int bins) noexcept {
        int i=0;
#if defined(_MSC_VER) && (defined(_M_X64) || defined(_M_IX86))
        // Native Windows profiling identified sustained spectral-MAC cost in
        // this loop. Make its four-float SIMD work explicit on MSVC instead of
        // depending on auto-vectorization of the two variable-offset stores.
        // Mono has N/2+1 bins, so neither the imaginary plane nor every input
        // partition is SIMD-aligned. Unaligned loads/stores are intentional.
        for(;i+4<=bins;i+=4) {
            const auto inputReal=_mm_loadu_ps(input+i);
            const auto inputImag=_mm_loadu_ps(input+bins+i);
            const auto impulseReal=_mm_loadu_ps(impulse+i);
            const auto impulseImag=_mm_loadu_ps(impulse+bins+i);
            const auto outputReal=_mm_loadu_ps(output+i);
            const auto outputImag=_mm_loadu_ps(output+bins+i);
            const auto real=_mm_sub_ps(_mm_add_ps(outputReal,_mm_mul_ps(inputReal,impulseReal)),
                                      _mm_mul_ps(inputImag,impulseImag));
            const auto imag=_mm_add_ps(_mm_add_ps(outputImag,_mm_mul_ps(inputReal,impulseImag)),
                                      _mm_mul_ps(inputImag,impulseReal));
            _mm_storeu_ps(output+i,real);
            _mm_storeu_ps(output+bins+i,imag);
        }
#elif defined(__APPLE__) && defined(__aarch64__)
        // The macOS attribution matrix places the 96 kHz / 32-sample cost in
        // this spectral MAC, while publication itself remains negligible.
        // AppleClang contracts the scalar multiply/add pairs on arm64. Express
        // the same two-step FMA/FMS arithmetic explicitly for four planar bins
        // so the frozen residue-bank output remains the compatibility gate.
        #pragma clang loop unroll_count(4)
        for(;i+4<=bins;i+=4) {
            const auto inputReal=vld1q_f32(input+i);
            const auto inputImag=vld1q_f32(input+bins+i);
            const auto impulseReal=vld1q_f32(impulse+i);
            const auto impulseImag=vld1q_f32(impulse+bins+i);
            const auto outputReal=vld1q_f32(output+i);
            const auto outputImag=vld1q_f32(output+bins+i);
            const auto real=vfmsq_f32(vfmaq_f32(outputReal,inputReal,impulseReal),
                                      inputImag,impulseImag);
            const auto imag=vfmaq_f32(vfmaq_f32(outputImag,inputReal,impulseImag),
                                      inputImag,impulseReal);
            vst1q_f32(output+i,real);
            vst1q_f32(output+bins+i,imag);
        }
#endif
        for(;i<bins;++i) {
            const float re=(output[i]+input[i]*impulse[i])-input[bins+i]*impulse[bins+i];
            const float im=(output[bins+i]+input[i]*impulse[bins+i])+input[bins+i]*impulse[i];
            output[i]=re;output[bins+i]=im;
        }
}
extern "C" __attribute__((noinline)) void scalar_ic1(const float* __restrict input,const float* __restrict impulse,float* __restrict output,int bins) noexcept {
        int i=0;
#if defined(_MSC_VER) && (defined(_M_X64) || defined(_M_IX86))
        // Native Windows profiling identified sustained spectral-MAC cost in
        // this loop. Make its four-float SIMD work explicit on MSVC instead of
        // depending on auto-vectorization of the two variable-offset stores.
        // Mono has N/2+1 bins, so neither the imaginary plane nor every input
        // partition is SIMD-aligned. Unaligned loads/stores are intentional.
        for(;i+4<=bins;i+=4) {
            const auto inputReal=_mm_loadu_ps(input+i);
            const auto inputImag=_mm_loadu_ps(input+bins+i);
            const auto impulseReal=_mm_loadu_ps(impulse+i);
            const auto impulseImag=_mm_loadu_ps(impulse+bins+i);
            const auto outputReal=_mm_loadu_ps(output+i);
            const auto outputImag=_mm_loadu_ps(output+bins+i);
            const auto real=_mm_sub_ps(_mm_add_ps(outputReal,_mm_mul_ps(inputReal,impulseReal)),
                                      _mm_mul_ps(inputImag,impulseImag));
            const auto imag=_mm_add_ps(_mm_add_ps(outputImag,_mm_mul_ps(inputReal,impulseImag)),
                                      _mm_mul_ps(inputImag,impulseReal));
            _mm_storeu_ps(output+i,real);
            _mm_storeu_ps(output+bins+i,imag);
        }
#endif
        #pragma clang loop vectorize_width(4) interleave_count(1)
        for(;i<bins;++i) {
            const float re=(output[i]+input[i]*impulse[i])-input[bins+i]*impulse[bins+i];
            const float im=(output[bins+i]+input[i]*impulse[bins+i])+input[bins+i]*impulse[i];
            output[i]=re;output[bins+i]=im;
        }
}
extern "C" __attribute__((noinline)) void scalar_ic2(const float* __restrict input,const float* __restrict impulse,float* __restrict output,int bins) noexcept {
        int i=0;
#if defined(_MSC_VER) && (defined(_M_X64) || defined(_M_IX86))
        // Native Windows profiling identified sustained spectral-MAC cost in
        // this loop. Make its four-float SIMD work explicit on MSVC instead of
        // depending on auto-vectorization of the two variable-offset stores.
        // Mono has N/2+1 bins, so neither the imaginary plane nor every input
        // partition is SIMD-aligned. Unaligned loads/stores are intentional.
        for(;i+4<=bins;i+=4) {
            const auto inputReal=_mm_loadu_ps(input+i);
            const auto inputImag=_mm_loadu_ps(input+bins+i);
            const auto impulseReal=_mm_loadu_ps(impulse+i);
            const auto impulseImag=_mm_loadu_ps(impulse+bins+i);
            const auto outputReal=_mm_loadu_ps(output+i);
            const auto outputImag=_mm_loadu_ps(output+bins+i);
            const auto real=_mm_sub_ps(_mm_add_ps(outputReal,_mm_mul_ps(inputReal,impulseReal)),
                                      _mm_mul_ps(inputImag,impulseImag));
            const auto imag=_mm_add_ps(_mm_add_ps(outputImag,_mm_mul_ps(inputReal,impulseImag)),
                                      _mm_mul_ps(inputImag,impulseReal));
            _mm_storeu_ps(output+i,real);
            _mm_storeu_ps(output+bins+i,imag);
        }
#endif
        #pragma clang loop vectorize_width(4) interleave_count(2)
        for(;i<bins;++i) {
            const float re=(output[i]+input[i]*impulse[i])-input[bins+i]*impulse[bins+i];
            const float im=(output[bins+i]+input[i]*impulse[bins+i])+input[bins+i]*impulse[i];
            output[i]=re;output[bins+i]=im;
        }
}
