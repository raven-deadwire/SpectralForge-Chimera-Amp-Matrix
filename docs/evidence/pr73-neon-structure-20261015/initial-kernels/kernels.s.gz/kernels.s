	.section	__TEXT,__text,regular,pure_instructions
	.build_version macos, 12, 0	sdk_version 15, 5
	.globl	_scalar                         ; -- Begin function scalar
	.p2align	2
_scalar:                                ; @scalar
Lfunc_begin0:
	.cfi_startproc
; %bb.0:
	.file	1 "/Users/runner/work/SpectralForge-Chimera-Amp-Matrix/SpectralForge-Chimera-Amp-Matrix" "evidence/kernels.cpp"
	.loc	1 25 9 prologue_end             ; evidence/kernels.cpp:25:9
	cmp	w3, #1
	b.lt	LBB0_5
; %bb.1:
	mov	w8, w3
	cmp	w3, #16
	b.hs	LBB0_6
; %bb.2:
	.loc	1 0 9 is_stmt 0                 ; evidence/kernels.cpp:0:9
	mov	x9, #0                          ; =0x0
LBB0_3:
	mov	x10, #0                         ; =0x0
	.loc	1 25 9                          ; evidence/kernels.cpp:25:9
	add	x11, x9, x8
	lsl	x13, x11, #2
	add	x11, x2, x13
	add	x12, x1, x13
	add	x13, x0, x13
	lsl	x16, x9, #2
	add	x14, x1, x16
	add	x15, x0, x16
	add	x16, x2, x16
	sub	x8, x8, x9
LBB0_4:                                 ; =>This Inner Loop Header: Depth=1
	.loc	1 26 29 is_stmt 1               ; evidence/kernels.cpp:26:29
	ldr	s0, [x16, x10, lsl #2]
	.loc	1 26 39 is_stmt 0               ; evidence/kernels.cpp:26:39
	ldr	s1, [x15, x10, lsl #2]
	.loc	1 26 48                         ; evidence/kernels.cpp:26:48
	ldr	s2, [x14, x10, lsl #2]
	.loc	1 26 60                         ; evidence/kernels.cpp:26:60
	ldr	s3, [x13, x10, lsl #2]
	.loc	1 26 74                         ; evidence/kernels.cpp:26:74
	ldr	s4, [x12, x10, lsl #2]
	.loc	1 26 38                         ; evidence/kernels.cpp:26:38
	fmadd	s0, s1, s2, s0
	.loc	1 26 59                         ; evidence/kernels.cpp:26:59
	fmsub	s0, s3, s4, s0
	.loc	1 27 29 is_stmt 1               ; evidence/kernels.cpp:27:29
	ldr	s5, [x11, x10, lsl #2]
	.loc	1 27 43 is_stmt 0               ; evidence/kernels.cpp:27:43
	fmadd	s1, s1, s4, s5
	.loc	1 27 69                         ; evidence/kernels.cpp:27:69
	fmadd	s1, s3, s2, s1
	.loc	1 28 22 is_stmt 1               ; evidence/kernels.cpp:28:22
	str	s0, [x16, x10, lsl #2]
	.loc	1 28 40 is_stmt 0               ; evidence/kernels.cpp:28:40
	str	s1, [x11, x10, lsl #2]
	.loc	1 25 15 is_stmt 1               ; evidence/kernels.cpp:25:15
	add	x10, x10, #1
	.loc	1 25 9 is_stmt 0                ; evidence/kernels.cpp:25:9
	cmp	x8, x10
	b.ne	LBB0_4
LBB0_5:
	.loc	1 30 1 is_stmt 1                ; evidence/kernels.cpp:30:1
	ret
LBB0_6:
	.loc	1 0 1 is_stmt 0                 ; evidence/kernels.cpp:0:1
	mov	x9, #0                          ; =0x0
	.loc	1 25 9 is_stmt 1                ; evidence/kernels.cpp:25:9
	lsl	x10, x8, #2
	add	x3, x2, x10
	lsl	x14, x8, #3
	add	x4, x0, x10
	add	x5, x2, x14
	add	x17, x1, x10
	cmp	x2, x0
	ccmp	x5, x0, #0, lo
	cset	w11, hi
	add	x16, x1, x14
	cmp	x3, x16
	ccmp	x17, x5, #2, lo
	cset	w12, lo
	cmp	x2, x1
	ccmp	x5, x1, #0, lo
	cset	w13, hi
	add	x6, x0, x14
	cmp	x6, x2
	ccmp	x0, x2, #2, hi
	cset	w14, lo
	cmp	x4, x2
	ccmp	x3, x0, #0, hi
	cset	w15, hi
	cmp	x16, x2
	ccmp	x1, x2, #2, hi
	cset	w16, lo
	cmp	x17, x2
	ccmp	x3, x1, #0, hi
	cset	w17, hi
	cmp	x4, x5
	ccmp	x3, x6, #2, lo
	b.lo	LBB0_3
; %bb.7:
	tbnz	w11, #0, LBB0_3
; %bb.8:
	tbnz	w12, #0, LBB0_3
; %bb.9:
	tbnz	w13, #0, LBB0_3
; %bb.10:
	tbnz	w14, #0, LBB0_3
; %bb.11:
	tbnz	w15, #0, LBB0_3
; %bb.12:
	tbnz	w16, #0, LBB0_3
; %bb.13:
	tbnz	w17, #0, LBB0_3
; %bb.14:
	and	x9, x8, #0x7ffffff8
	add	x11, x2, #16
	add	x12, x0, #16
	add	x13, x1, #16
	mov	x14, x9
LBB0_15:                                ; =>This Inner Loop Header: Depth=1
	.loc	1 26 29                         ; evidence/kernels.cpp:26:29
	ldp	q0, q1, [x11, #-16]
	.loc	1 26 39 is_stmt 0               ; evidence/kernels.cpp:26:39
	ldp	q2, q3, [x12, #-16]
	.loc	1 26 48                         ; evidence/kernels.cpp:26:48
	ldp	q4, q5, [x13, #-16]
	.loc	1 26 38                         ; evidence/kernels.cpp:26:38
	fmla.4s	v0, v4, v2
	fmla.4s	v1, v5, v3
	.loc	1 26 60                         ; evidence/kernels.cpp:26:60
	add	x15, x12, x10
	ldp	q6, q7, [x15, #-16]
	.loc	1 26 74                         ; evidence/kernels.cpp:26:74
	add	x15, x13, x10
	ldp	q16, q17, [x15, #-16]
	.loc	1 26 59                         ; evidence/kernels.cpp:26:59
	fmls.4s	v0, v16, v6
	fmls.4s	v1, v17, v7
	.loc	1 27 29 is_stmt 1               ; evidence/kernels.cpp:27:29
	add	x15, x11, x10
	ldp	q18, q19, [x15, #-16]
	.loc	1 27 43 is_stmt 0               ; evidence/kernels.cpp:27:43
	fmla.4s	v18, v16, v2
	fmla.4s	v19, v17, v3
	.loc	1 27 69                         ; evidence/kernels.cpp:27:69
	fmla.4s	v18, v4, v6
	fmla.4s	v19, v5, v7
	.loc	1 28 22 is_stmt 1               ; evidence/kernels.cpp:28:22
	stp	q0, q1, [x11, #-16]
	.loc	1 28 40 is_stmt 0               ; evidence/kernels.cpp:28:40
	stp	q18, q19, [x15, #-16]
	.loc	1 25 21 is_stmt 1               ; evidence/kernels.cpp:25:21
	add	x11, x11, #32
	add	x12, x12, #32
	add	x13, x13, #32
	subs	x14, x14, #8
	b.ne	LBB0_15
; %bb.16:
	.loc	1 25 9 is_stmt 0                ; evidence/kernels.cpp:25:9
	cmp	x9, x8
	b.ne	LBB0_3
	b	LBB0_5
Ltmp0:
Lfunc_end0:
	.cfi_endproc
                                        ; -- End function
	.globl	_neon4                          ; -- Begin function neon4
	.p2align	2
_neon4:                                 ; @neon4
Lfunc_begin1:
	.loc	1 31 0 is_stmt 1                ; evidence/kernels.cpp:31:0
	.cfi_startproc
; %bb.0:
	stp	x24, x23, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
                                        ; kill: def $w3 killed $w3 def $x3
Ltmp1:
	.loc	1 59 9 prologue_end             ; evidence/kernels.cpp:59:9
	cmp	w3, #4
	b.ge	LBB1_2
; %bb.1:
	.loc	1 0 9 is_stmt 0                 ; evidence/kernels.cpp:0:9
	mov	w8, #0                          ; =0x0
	b	LBB1_4
LBB1_2:
	.loc	1 59 9                          ; evidence/kernels.cpp:59:9
	and	w8, w3, #0x7ffffffc
	ubfiz	x9, x3, #2, #32
	mov	w10, #4                         ; =0x4
	mov	x11, x0
	mov	x12, x1
	mov	x13, x2
	mov	w14, w3
LBB1_3:                                 ; =>This Inner Loop Header: Depth=1
	.loc	1 60 34 is_stmt 1               ; evidence/kernels.cpp:60:34
	ldr	q0, [x11]
	.loc	1 61 34                         ; evidence/kernels.cpp:61:34
	ldr	q1, [x11, x9]
	.loc	1 62 36                         ; evidence/kernels.cpp:62:36
	ldr	q2, [x12]
	.loc	1 63 36                         ; evidence/kernels.cpp:63:36
	ldr	q3, [x12, x9]
	.loc	1 64 35                         ; evidence/kernels.cpp:64:35
	ldr	q4, [x13]
	.loc	1 65 35                         ; evidence/kernels.cpp:65:35
	ldr	q5, [x13, x9]
	.loc	1 66 39                         ; evidence/kernels.cpp:66:39
	fmla.4s	v4, v2, v0
	.loc	1 66 29 is_stmt 0               ; evidence/kernels.cpp:66:29
	fmls.4s	v4, v3, v1
	.loc	1 68 39 is_stmt 1               ; evidence/kernels.cpp:68:39
	fmla.4s	v5, v3, v0
	.loc	1 68 29 is_stmt 0               ; evidence/kernels.cpp:68:29
	fmla.4s	v5, v2, v1
	.loc	1 70 13 is_stmt 1               ; evidence/kernels.cpp:70:13
	str	q4, [x13]
	.loc	1 71 13                         ; evidence/kernels.cpp:71:13
	str	q5, [x13, x9]
	.loc	1 59 15                         ; evidence/kernels.cpp:59:15
	add	x10, x10, #4
	.loc	1 59 17 is_stmt 0               ; evidence/kernels.cpp:59:17
	add	x13, x13, #16
	add	x12, x12, #16
	add	x11, x11, #16
	.loc	1 59 9                          ; evidence/kernels.cpp:59:9
	cmp	x10, x14
	b.ls	LBB1_3
LBB1_4:
	.loc	1 74 9 is_stmt 1                ; evidence/kernels.cpp:74:9
	cmp	w8, w3
	b.ge	LBB1_9
; %bb.5:
	mov	w12, w8
	sxtw	x8, w3
	sub	x9, x8, x12
	cmp	x9, #15
	b.hi	LBB1_10
LBB1_6:
	.loc	1 0 9 is_stmt 0                 ; evidence/kernels.cpp:0:9
	mov	x11, x12
LBB1_7:
	mov	x9, #0                          ; =0x0
	.loc	1 74 9                          ; evidence/kernels.cpp:74:9
	add	x10, x11, x8
	lsl	x13, x10, #2
	add	x10, x0, x13
	add	x12, x1, x13
	add	x13, x2, x13
	lsl	x16, x11, #2
	add	x14, x1, x16
	add	x15, x0, x16
	add	x16, x2, x16
	sub	x8, x8, x11
LBB1_8:                                 ; =>This Inner Loop Header: Depth=1
	.loc	1 75 29 is_stmt 1               ; evidence/kernels.cpp:75:29
	ldr	s0, [x16, x9, lsl #2]
	.loc	1 75 39 is_stmt 0               ; evidence/kernels.cpp:75:39
	ldr	s1, [x15, x9, lsl #2]
	.loc	1 75 48                         ; evidence/kernels.cpp:75:48
	ldr	s2, [x14, x9, lsl #2]
	.loc	1 75 60                         ; evidence/kernels.cpp:75:60
	ldr	s3, [x10, x9, lsl #2]
	.loc	1 75 74                         ; evidence/kernels.cpp:75:74
	ldr	s4, [x12, x9, lsl #2]
	.loc	1 75 38                         ; evidence/kernels.cpp:75:38
	fmadd	s0, s1, s2, s0
	.loc	1 75 59                         ; evidence/kernels.cpp:75:59
	fmsub	s0, s3, s4, s0
	.loc	1 76 29 is_stmt 1               ; evidence/kernels.cpp:76:29
	ldr	s5, [x13, x9, lsl #2]
	.loc	1 76 43 is_stmt 0               ; evidence/kernels.cpp:76:43
	fmadd	s1, s1, s4, s5
	.loc	1 76 69                         ; evidence/kernels.cpp:76:69
	fmadd	s1, s3, s2, s1
	.loc	1 77 22 is_stmt 1               ; evidence/kernels.cpp:77:22
	str	s0, [x16, x9, lsl #2]
	.loc	1 77 40 is_stmt 0               ; evidence/kernels.cpp:77:40
	str	s1, [x13, x9, lsl #2]
	.loc	1 74 15 is_stmt 1               ; evidence/kernels.cpp:74:15
	add	x9, x9, #1
	.loc	1 74 9 is_stmt 0                ; evidence/kernels.cpp:74:9
	cmp	x8, x9
	b.ne	LBB1_8
LBB1_9:
	.loc	1 79 1 epilogue_begin is_stmt 1 ; evidence/kernels.cpp:79:1
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #48             ; 16-byte Folded Reload
	ret
LBB1_10:
	.loc	1 74 9                          ; evidence/kernels.cpp:74:9
	add	x10, x8, x12
	lsl	x15, x10, #2
	add	x4, x2, x15
	lsl	x13, x8, #3
	add	x5, x2, x13
	add	x6, x0, x13
	lsl	x10, x12, #2
	add	x16, x0, x10
	lsl	x14, x8, #2
	add	x17, x1, x15
	add	x3, x1, x10
	add	x7, x2, x14
	add	x19, x0, x14
	cmp	x4, x19
	ccmp	x16, x5, #2, lo
	cset	w11, lo
	add	x20, x1, x13
	cmp	x4, x20
	ccmp	x17, x5, #2, lo
	cset	w13, lo
	add	x21, x1, x14
	cmp	x4, x21
	ccmp	x3, x5, #2, lo
	cset	w14, lo
	add	x22, x2, x10
	cmp	x22, x6
	add	x23, x0, x15
	ccmp	x23, x7, #2, lo
	cset	w15, lo
	cmp	x22, x19
	ccmp	x16, x7, #2, lo
	cset	w16, lo
	cmp	x22, x20
	ccmp	x17, x7, #2, lo
	cset	w17, lo
	cmp	x22, x21
	ccmp	x3, x7, #2, lo
	cset	w3, lo
	cmp	x23, x5
	ccmp	x4, x6, #2, lo
	b.lo	LBB1_6
; %bb.11:
	tbnz	w11, #0, LBB1_6
; %bb.12:
	tbnz	w13, #0, LBB1_6
; %bb.13:
	tbnz	w14, #0, LBB1_6
; %bb.14:
	tbnz	w15, #0, LBB1_6
; %bb.15:
	tbnz	w16, #0, LBB1_6
; %bb.16:
	tbnz	w17, #0, LBB1_6
; %bb.17:
	tbnz	w3, #0, LBB1_6
; %bb.18:
	and	x13, x9, #0xfffffffffffffff8
	add	x11, x13, x12
	add	x12, x8, x12
	lsl	x12, x12, #2
	add	x12, x12, #16
	mov	x14, x1
	mov	x15, x2
	mov	x16, x0
	mov	x17, x13
LBB1_19:                                ; =>This Inner Loop Header: Depth=1
	.loc	1 75 29                         ; evidence/kernels.cpp:75:29
	add	x3, x15, x10
	ldp	q0, q1, [x3]
	.loc	1 75 39 is_stmt 0               ; evidence/kernels.cpp:75:39
	add	x4, x16, x10
	ldp	q2, q3, [x4]
	.loc	1 75 48                         ; evidence/kernels.cpp:75:48
	add	x4, x14, x10
	ldp	q4, q5, [x4]
	.loc	1 75 38                         ; evidence/kernels.cpp:75:38
	fmla.4s	v0, v4, v2
	fmla.4s	v1, v5, v3
	.loc	1 75 60                         ; evidence/kernels.cpp:75:60
	add	x4, x16, x12
	ldp	q6, q7, [x4, #-16]
	.loc	1 75 74                         ; evidence/kernels.cpp:75:74
	add	x4, x14, x12
	ldp	q16, q17, [x4, #-16]
	.loc	1 75 59                         ; evidence/kernels.cpp:75:59
	fmls.4s	v0, v16, v6
	fmls.4s	v1, v17, v7
	.loc	1 76 29 is_stmt 1               ; evidence/kernels.cpp:76:29
	add	x4, x15, x12
	ldp	q18, q19, [x4, #-16]
	.loc	1 76 43 is_stmt 0               ; evidence/kernels.cpp:76:43
	fmla.4s	v18, v16, v2
	fmla.4s	v19, v17, v3
	.loc	1 76 69                         ; evidence/kernels.cpp:76:69
	fmla.4s	v18, v4, v6
	fmla.4s	v19, v5, v7
	.loc	1 77 22 is_stmt 1               ; evidence/kernels.cpp:77:22
	stp	q0, q1, [x3]
	.loc	1 77 40 is_stmt 0               ; evidence/kernels.cpp:77:40
	stp	q18, q19, [x4, #-16]
	add	x16, x16, #32
	add	x15, x15, #32
	add	x14, x14, #32
	subs	x17, x17, #8
	b.ne	LBB1_19
; %bb.20:
	.loc	1 74 9 is_stmt 1                ; evidence/kernels.cpp:74:9
	cmp	x9, x13
	b.ne	LBB1_7
	b	LBB1_9
Ltmp2:
Lfunc_end1:
	.cfi_endproc
                                        ; -- End function
	.globl	_neon8                          ; -- Begin function neon8
	.p2align	2
_neon8:                                 ; @neon8
Lfunc_begin2:
	.loc	1 80 0                          ; evidence/kernels.cpp:80:0
	.cfi_startproc
; %bb.0:
	stp	x24, x23, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
                                        ; kill: def $w3 killed $w3 def $x3
Ltmp3:
	.loc	1 109 9 prologue_end            ; evidence/kernels.cpp:109:9
	cmp	w3, #4
	b.ge	LBB2_2
; %bb.1:
	.loc	1 0 9 is_stmt 0                 ; evidence/kernels.cpp:0:9
	mov	w8, #0                          ; =0x0
	.loc	1 109 9                         ; evidence/kernels.cpp:109:9
	b	LBB2_8
LBB2_2:
	.loc	1 0 9                           ; evidence/kernels.cpp:0:9
	mov	w13, w3
	.loc	1 109 9                         ; evidence/kernels.cpp:109:9
	and	w8, w3, #0x7ffffffc
	mov	w9, #7                          ; =0x7
	cmp	x13, #7
	csel	x9, x13, x9, hi
	sub	x10, x9, #4
	cmp	x10, #4
	b.hs	LBB2_4
; %bb.3:
	.loc	1 0 9                           ; evidence/kernels.cpp:0:9
	mov	x9, #0                          ; =0x0
	b	LBB2_6
LBB2_4:
	mov	x9, #0                          ; =0x0
	.loc	1 109 9                         ; evidence/kernels.cpp:109:9
	and	x11, x10, #0xfffffffffffffffc
	add	x11, x11, #4
	and	x11, x11, #0xfffffffffffffff8
	add	x12, x0, #16
	lsl	x13, x13, #2
	add	x14, x1, #16
	add	x15, x2, #16
LBB2_5:                                 ; =>This Inner Loop Header: Depth=1
	.loc	1 110 34 is_stmt 1              ; evidence/kernels.cpp:110:34
	ldur	q0, [x12, #-16]
	.loc	1 111 34                        ; evidence/kernels.cpp:111:34
	add	x16, x12, x13
	.loc	1 112 36                        ; evidence/kernels.cpp:112:36
	ldur	q1, [x14, #-16]
	.loc	1 113 36                        ; evidence/kernels.cpp:113:36
	add	x17, x14, x13
	ldur	q2, [x17, #-16]
	.loc	1 114 35                        ; evidence/kernels.cpp:114:35
	ldur	q3, [x15, #-16]
	.loc	1 115 35                        ; evidence/kernels.cpp:115:35
	add	x4, x15, x13
	.loc	1 116 39                        ; evidence/kernels.cpp:116:39
	fmla.4s	v3, v1, v0
	.loc	1 115 35                        ; evidence/kernels.cpp:115:35
	ldp	q4, q5, [x4, #-16]
	.loc	1 118 39                        ; evidence/kernels.cpp:118:39
	fmla.4s	v4, v2, v0
	.loc	1 111 34                        ; evidence/kernels.cpp:111:34
	ldur	q0, [x16, #-16]
	.loc	1 116 29                        ; evidence/kernels.cpp:116:29
	fmls.4s	v3, v2, v0
	.loc	1 118 29                        ; evidence/kernels.cpp:118:29
	fmla.4s	v4, v1, v0
	.loc	1 120 13                        ; evidence/kernels.cpp:120:13
	stur	q3, [x15, #-16]
	.loc	1 121 13                        ; evidence/kernels.cpp:121:13
	stur	q4, [x4, #-16]
	.loc	1 110 34                        ; evidence/kernels.cpp:110:34
	ldr	q0, [x12], #32
	.loc	1 111 34                        ; evidence/kernels.cpp:111:34
	ldr	q1, [x16]
	.loc	1 112 36                        ; evidence/kernels.cpp:112:36
	ldr	q2, [x14], #32
	.loc	1 113 36                        ; evidence/kernels.cpp:113:36
	ldr	q3, [x17]
	.loc	1 114 35                        ; evidence/kernels.cpp:114:35
	ldr	q4, [x15]
	.loc	1 116 39                        ; evidence/kernels.cpp:116:39
	fmla.4s	v4, v2, v0
	.loc	1 116 29 is_stmt 0              ; evidence/kernels.cpp:116:29
	fmls.4s	v4, v3, v1
	.loc	1 118 39 is_stmt 1              ; evidence/kernels.cpp:118:39
	fmla.4s	v5, v3, v0
	.loc	1 118 29 is_stmt 0              ; evidence/kernels.cpp:118:29
	fmla.4s	v5, v2, v1
	.loc	1 109 9 is_stmt 1               ; evidence/kernels.cpp:109:9
	add	x9, x9, #8
	.loc	1 120 13                        ; evidence/kernels.cpp:120:13
	str	q4, [x15], #32
	.loc	1 121 13                        ; evidence/kernels.cpp:121:13
	str	q5, [x4]
	.loc	1 109 9                         ; evidence/kernels.cpp:109:9
	cmp	x11, x9
	b.ne	LBB2_5
LBB2_6:
	tbnz	w10, #2, LBB2_8
; %bb.7:
	.loc	1 0 9 is_stmt 0                 ; evidence/kernels.cpp:0:9
	ubfiz	x10, x3, #2, #32
	add	x11, x0, x10
	add	x12, x1, x10
	add	x10, x2, x10
	.loc	1 110 34 is_stmt 1              ; evidence/kernels.cpp:110:34
	lsl	x9, x9, #2
	ldr	q0, [x0, x9]
	.loc	1 111 34                        ; evidence/kernels.cpp:111:34
	ldr	q1, [x11, x9]
	.loc	1 112 36                        ; evidence/kernels.cpp:112:36
	ldr	q2, [x1, x9]
	.loc	1 113 36                        ; evidence/kernels.cpp:113:36
	ldr	q3, [x12, x9]
	.loc	1 114 35                        ; evidence/kernels.cpp:114:35
	ldr	q4, [x2, x9]
	.loc	1 115 35                        ; evidence/kernels.cpp:115:35
	ldr	q5, [x10, x9]
	.loc	1 116 39                        ; evidence/kernels.cpp:116:39
	fmla.4s	v4, v2, v0
	.loc	1 116 29 is_stmt 0              ; evidence/kernels.cpp:116:29
	fmls.4s	v4, v3, v1
	.loc	1 118 39 is_stmt 1              ; evidence/kernels.cpp:118:39
	fmla.4s	v5, v3, v0
	.loc	1 118 29 is_stmt 0              ; evidence/kernels.cpp:118:29
	fmla.4s	v5, v2, v1
	.loc	1 120 13 is_stmt 1              ; evidence/kernels.cpp:120:13
	str	q4, [x2, x9]
	.loc	1 121 13                        ; evidence/kernels.cpp:121:13
	str	q5, [x10, x9]
LBB2_8:
	.loc	1 124 9                         ; evidence/kernels.cpp:124:9
	cmp	w8, w3
	b.ge	LBB2_13
; %bb.9:
	mov	w12, w8
	sxtw	x8, w3
	sub	x9, x8, x12
	cmp	x9, #15
	b.hi	LBB2_14
LBB2_10:
	.loc	1 0 9 is_stmt 0                 ; evidence/kernels.cpp:0:9
	mov	x11, x12
LBB2_11:
	mov	x9, #0                          ; =0x0
	.loc	1 124 9                         ; evidence/kernels.cpp:124:9
	add	x10, x11, x8
	lsl	x13, x10, #2
	add	x10, x0, x13
	add	x12, x1, x13
	add	x13, x2, x13
	lsl	x16, x11, #2
	add	x14, x1, x16
	add	x15, x0, x16
	add	x16, x2, x16
	sub	x8, x8, x11
LBB2_12:                                ; =>This Inner Loop Header: Depth=1
	.loc	1 125 29 is_stmt 1              ; evidence/kernels.cpp:125:29
	ldr	s0, [x16, x9, lsl #2]
	.loc	1 125 39 is_stmt 0              ; evidence/kernels.cpp:125:39
	ldr	s1, [x15, x9, lsl #2]
	.loc	1 125 48                        ; evidence/kernels.cpp:125:48
	ldr	s2, [x14, x9, lsl #2]
	.loc	1 125 60                        ; evidence/kernels.cpp:125:60
	ldr	s3, [x10, x9, lsl #2]
	.loc	1 125 74                        ; evidence/kernels.cpp:125:74
	ldr	s4, [x12, x9, lsl #2]
	.loc	1 125 38                        ; evidence/kernels.cpp:125:38
	fmadd	s0, s1, s2, s0
	.loc	1 125 59                        ; evidence/kernels.cpp:125:59
	fmsub	s0, s3, s4, s0
	.loc	1 126 29 is_stmt 1              ; evidence/kernels.cpp:126:29
	ldr	s5, [x13, x9, lsl #2]
	.loc	1 126 43 is_stmt 0              ; evidence/kernels.cpp:126:43
	fmadd	s1, s1, s4, s5
	.loc	1 126 69                        ; evidence/kernels.cpp:126:69
	fmadd	s1, s3, s2, s1
	.loc	1 127 22 is_stmt 1              ; evidence/kernels.cpp:127:22
	str	s0, [x16, x9, lsl #2]
	.loc	1 127 40 is_stmt 0              ; evidence/kernels.cpp:127:40
	str	s1, [x13, x9, lsl #2]
	.loc	1 124 15 is_stmt 1              ; evidence/kernels.cpp:124:15
	add	x9, x9, #1
	.loc	1 124 9 is_stmt 0               ; evidence/kernels.cpp:124:9
	cmp	x8, x9
	b.ne	LBB2_12
LBB2_13:
	.loc	1 129 1 epilogue_begin is_stmt 1 ; evidence/kernels.cpp:129:1
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #48             ; 16-byte Folded Reload
	ret
LBB2_14:
	.loc	1 124 9                         ; evidence/kernels.cpp:124:9
	add	x10, x8, x12
	lsl	x15, x10, #2
	add	x4, x2, x15
	lsl	x13, x8, #3
	add	x5, x2, x13
	add	x6, x0, x13
	lsl	x10, x12, #2
	add	x16, x0, x10
	lsl	x14, x8, #2
	add	x17, x1, x15
	add	x3, x1, x10
	add	x7, x2, x14
	add	x19, x0, x14
	cmp	x4, x19
	ccmp	x16, x5, #2, lo
	cset	w11, lo
	add	x20, x1, x13
	cmp	x4, x20
	ccmp	x17, x5, #2, lo
	cset	w13, lo
	add	x21, x1, x14
	cmp	x4, x21
	ccmp	x3, x5, #2, lo
	cset	w14, lo
	add	x22, x2, x10
	cmp	x22, x6
	add	x23, x0, x15
	ccmp	x23, x7, #2, lo
	cset	w15, lo
	cmp	x22, x19
	ccmp	x16, x7, #2, lo
	cset	w16, lo
	cmp	x22, x20
	ccmp	x17, x7, #2, lo
	cset	w17, lo
	cmp	x22, x21
	ccmp	x3, x7, #2, lo
	cset	w3, lo
	cmp	x23, x5
	ccmp	x4, x6, #2, lo
	b.lo	LBB2_10
; %bb.15:
	tbnz	w11, #0, LBB2_10
; %bb.16:
	tbnz	w13, #0, LBB2_10
; %bb.17:
	tbnz	w14, #0, LBB2_10
; %bb.18:
	tbnz	w15, #0, LBB2_10
; %bb.19:
	tbnz	w16, #0, LBB2_10
; %bb.20:
	tbnz	w17, #0, LBB2_10
; %bb.21:
	tbnz	w3, #0, LBB2_10
; %bb.22:
	and	x13, x9, #0xfffffffffffffff8
	add	x11, x13, x12
	add	x12, x8, x12
	lsl	x12, x12, #2
	add	x12, x12, #16
	mov	x14, x1
	mov	x15, x2
	mov	x16, x0
	mov	x17, x13
LBB2_23:                                ; =>This Inner Loop Header: Depth=1
	.loc	1 125 29                        ; evidence/kernels.cpp:125:29
	add	x3, x15, x10
	ldp	q0, q1, [x3]
	.loc	1 125 39 is_stmt 0              ; evidence/kernels.cpp:125:39
	add	x4, x16, x10
	ldp	q2, q3, [x4]
	.loc	1 125 48                        ; evidence/kernels.cpp:125:48
	add	x4, x14, x10
	ldp	q4, q5, [x4]
	.loc	1 125 38                        ; evidence/kernels.cpp:125:38
	fmla.4s	v0, v4, v2
	fmla.4s	v1, v5, v3
	.loc	1 125 60                        ; evidence/kernels.cpp:125:60
	add	x4, x16, x12
	ldp	q6, q7, [x4, #-16]
	.loc	1 125 74                        ; evidence/kernels.cpp:125:74
	add	x4, x14, x12
	ldp	q16, q17, [x4, #-16]
	.loc	1 125 59                        ; evidence/kernels.cpp:125:59
	fmls.4s	v0, v16, v6
	fmls.4s	v1, v17, v7
	.loc	1 126 29 is_stmt 1              ; evidence/kernels.cpp:126:29
	add	x4, x15, x12
	ldp	q18, q19, [x4, #-16]
	.loc	1 126 43 is_stmt 0              ; evidence/kernels.cpp:126:43
	fmla.4s	v18, v16, v2
	fmla.4s	v19, v17, v3
	.loc	1 126 69                        ; evidence/kernels.cpp:126:69
	fmla.4s	v18, v4, v6
	fmla.4s	v19, v5, v7
	.loc	1 127 22 is_stmt 1              ; evidence/kernels.cpp:127:22
	stp	q0, q1, [x3]
	.loc	1 127 40 is_stmt 0              ; evidence/kernels.cpp:127:40
	stp	q18, q19, [x4, #-16]
	add	x16, x16, #32
	add	x15, x15, #32
	add	x14, x14, #32
	subs	x17, x17, #8
	b.ne	LBB2_23
; %bb.24:
	.loc	1 124 9 is_stmt 1               ; evidence/kernels.cpp:124:9
	cmp	x9, x13
	b.ne	LBB2_11
	b	LBB2_13
Ltmp4:
Lfunc_end2:
	.cfi_endproc
                                        ; -- End function
	.globl	_neon16                         ; -- Begin function neon16
	.p2align	2
_neon16:                                ; @neon16
Lfunc_begin3:
	.loc	1 130 0                         ; evidence/kernels.cpp:130:0
	.cfi_startproc
; %bb.0:
	stp	x24, x23, [sp, #-48]!           ; 16-byte Folded Spill
	stp	x22, x21, [sp, #16]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             ; 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
                                        ; kill: def $w3 killed $w3 def $x3
Ltmp5:
	.loc	1 159 9 prologue_end            ; evidence/kernels.cpp:159:9
	cmp	w3, #4
	b.ge	LBB3_2
; %bb.1:
	.loc	1 0 9 is_stmt 0                 ; evidence/kernels.cpp:0:9
	mov	w8, #0                          ; =0x0
	.loc	1 159 9                         ; evidence/kernels.cpp:159:9
	b	LBB3_9
LBB3_2:
	.loc	1 0 9                           ; evidence/kernels.cpp:0:9
	mov	w10, w3
	.loc	1 159 9                         ; evidence/kernels.cpp:159:9
	and	w8, w3, #0x7ffffffc
	mov	w9, #7                          ; =0x7
	cmp	x10, #7
	csel	x9, x10, x9, hi
	sub	x11, x9, #4
	lsr	x9, x11, #2
	add	x16, x9, #1
	and	x9, x16, #0x3
	cmp	x11, #12
	b.hs	LBB3_4
; %bb.3:
	.loc	1 0 9                           ; evidence/kernels.cpp:0:9
	mov	x11, #0                         ; =0x0
	b	LBB3_6
LBB3_4:
	mov	x12, #0                         ; =0x0
	mov	x11, #0                         ; =0x0
	ubfiz	x15, x3, #2, #32
	add	x13, x0, x15
	add	x14, x1, x15
	add	x15, x2, x15
	.loc	1 159 9                         ; evidence/kernels.cpp:159:9
	lsl	x16, x16, #4
	and	x16, x16, #0xffffffffffffffc0
LBB3_5:                                 ; =>This Inner Loop Header: Depth=1
	.loc	1 160 34 is_stmt 1              ; evidence/kernels.cpp:160:34
	add	x5, x0, x12
	.loc	1 161 34                        ; evidence/kernels.cpp:161:34
	add	x6, x13, x12
	.loc	1 160 34                        ; evidence/kernels.cpp:160:34
	ldr	q0, [x5]
	.loc	1 161 34                        ; evidence/kernels.cpp:161:34
	ldr	q1, [x6]
	.loc	1 162 36                        ; evidence/kernels.cpp:162:36
	add	x7, x1, x12
	ldr	q2, [x7]
	.loc	1 163 36                        ; evidence/kernels.cpp:163:36
	add	x19, x14, x12
	.loc	1 164 35                        ; evidence/kernels.cpp:164:35
	add	x17, x2, x12
	.loc	1 163 36                        ; evidence/kernels.cpp:163:36
	ldr	q3, [x19]
	.loc	1 164 35                        ; evidence/kernels.cpp:164:35
	ldr	q4, [x17]
	.loc	1 165 35                        ; evidence/kernels.cpp:165:35
	add	x4, x15, x12
	.loc	1 166 39                        ; evidence/kernels.cpp:166:39
	fmla.4s	v4, v2, v0
	.loc	1 165 35                        ; evidence/kernels.cpp:165:35
	ldp	q5, q6, [x4]
	.loc	1 166 29                        ; evidence/kernels.cpp:166:29
	fmls.4s	v4, v3, v1
	.loc	1 168 39                        ; evidence/kernels.cpp:168:39
	fmla.4s	v5, v3, v0
	.loc	1 168 29 is_stmt 0              ; evidence/kernels.cpp:168:29
	fmla.4s	v5, v2, v1
	.loc	1 170 13 is_stmt 1              ; evidence/kernels.cpp:170:13
	str	q4, [x17]
	.loc	1 171 13                        ; evidence/kernels.cpp:171:13
	str	q5, [x4]
	.loc	1 160 34                        ; evidence/kernels.cpp:160:34
	ldr	q0, [x5, #16]
	.loc	1 161 34                        ; evidence/kernels.cpp:161:34
	ldr	q1, [x6, #16]
	.loc	1 162 36                        ; evidence/kernels.cpp:162:36
	ldr	q2, [x7, #16]
	.loc	1 163 36                        ; evidence/kernels.cpp:163:36
	ldr	q3, [x19, #16]
	.loc	1 164 35                        ; evidence/kernels.cpp:164:35
	ldr	q4, [x17, #16]
	.loc	1 166 39                        ; evidence/kernels.cpp:166:39
	fmla.4s	v4, v2, v0
	.loc	1 168 39                        ; evidence/kernels.cpp:168:39
	fmla.4s	v6, v3, v0
	.loc	1 166 29                        ; evidence/kernels.cpp:166:29
	fmls.4s	v4, v3, v1
	.loc	1 168 29                        ; evidence/kernels.cpp:168:29
	fmla.4s	v6, v2, v1
	.loc	1 170 13                        ; evidence/kernels.cpp:170:13
	str	q4, [x17, #16]
	.loc	1 171 13                        ; evidence/kernels.cpp:171:13
	str	q6, [x4, #16]
	.loc	1 160 34                        ; evidence/kernels.cpp:160:34
	ldr	q0, [x5, #32]
	.loc	1 161 34                        ; evidence/kernels.cpp:161:34
	ldr	q1, [x6, #32]
	.loc	1 162 36                        ; evidence/kernels.cpp:162:36
	ldr	q2, [x7, #32]
	.loc	1 163 36                        ; evidence/kernels.cpp:163:36
	ldr	q3, [x19, #32]
	.loc	1 164 35                        ; evidence/kernels.cpp:164:35
	ldr	q4, [x17, #32]
	.loc	1 165 35                        ; evidence/kernels.cpp:165:35
	ldp	q5, q6, [x4, #32]
	.loc	1 168 39                        ; evidence/kernels.cpp:168:39
	fmla.4s	v5, v3, v0
	.loc	1 166 39                        ; evidence/kernels.cpp:166:39
	fmla.4s	v4, v2, v0
	.loc	1 166 29 is_stmt 0              ; evidence/kernels.cpp:166:29
	fmls.4s	v4, v3, v1
	.loc	1 168 29 is_stmt 1              ; evidence/kernels.cpp:168:29
	fmla.4s	v5, v2, v1
	.loc	1 170 13                        ; evidence/kernels.cpp:170:13
	str	q4, [x17, #32]
	.loc	1 171 13                        ; evidence/kernels.cpp:171:13
	str	q5, [x4, #32]
	.loc	1 160 34                        ; evidence/kernels.cpp:160:34
	ldr	q0, [x5, #48]
	.loc	1 161 34                        ; evidence/kernels.cpp:161:34
	ldr	q1, [x6, #48]
	.loc	1 162 36                        ; evidence/kernels.cpp:162:36
	ldr	q2, [x7, #48]
	.loc	1 163 36                        ; evidence/kernels.cpp:163:36
	ldr	q3, [x19, #48]
	.loc	1 164 35                        ; evidence/kernels.cpp:164:35
	ldr	q4, [x17, #48]
	.loc	1 166 39                        ; evidence/kernels.cpp:166:39
	fmla.4s	v4, v2, v0
	.loc	1 168 39                        ; evidence/kernels.cpp:168:39
	fmla.4s	v6, v3, v0
	.loc	1 166 29                        ; evidence/kernels.cpp:166:29
	fmls.4s	v4, v3, v1
	.loc	1 168 29                        ; evidence/kernels.cpp:168:29
	fmla.4s	v6, v2, v1
	.loc	1 170 13                        ; evidence/kernels.cpp:170:13
	str	q4, [x17, #48]
	.loc	1 171 13                        ; evidence/kernels.cpp:171:13
	str	q6, [x4, #48]
	.loc	1 159 9                         ; evidence/kernels.cpp:159:9
	add	x11, x11, #16
	add	x12, x12, #64
	cmp	x16, x12
	b.ne	LBB3_5
LBB3_6:
	cbz	x9, LBB3_9
; %bb.7:
	.loc	1 0 9 is_stmt 0                 ; evidence/kernels.cpp:0:9
	mov	x12, #0                         ; =0x0
	.loc	1 159 9                         ; evidence/kernels.cpp:159:9
	lsl	x16, x11, #2
	add	x15, x16, x10, lsl #2
	add	x10, x2, x15
	add	x11, x2, x16
	add	x13, x1, x15
	add	x14, x1, x16
	add	x15, x0, x15
	add	x16, x0, x16
	lsl	x9, x9, #4
LBB3_8:                                 ; =>This Inner Loop Header: Depth=1
	.loc	1 160 34 is_stmt 1              ; evidence/kernels.cpp:160:34
	ldr	q0, [x16, x12]
	.loc	1 161 34                        ; evidence/kernels.cpp:161:34
	ldr	q1, [x15, x12]
	.loc	1 162 36                        ; evidence/kernels.cpp:162:36
	ldr	q2, [x14, x12]
	.loc	1 163 36                        ; evidence/kernels.cpp:163:36
	ldr	q3, [x13, x12]
	.loc	1 164 35                        ; evidence/kernels.cpp:164:35
	ldr	q4, [x11, x12]
	.loc	1 165 35                        ; evidence/kernels.cpp:165:35
	ldr	q5, [x10, x12]
	.loc	1 166 39                        ; evidence/kernels.cpp:166:39
	fmla.4s	v4, v2, v0
	.loc	1 166 29 is_stmt 0              ; evidence/kernels.cpp:166:29
	fmls.4s	v4, v3, v1
	.loc	1 168 39 is_stmt 1              ; evidence/kernels.cpp:168:39
	fmla.4s	v5, v3, v0
	.loc	1 168 29 is_stmt 0              ; evidence/kernels.cpp:168:29
	fmla.4s	v5, v2, v1
	.loc	1 170 13 is_stmt 1              ; evidence/kernels.cpp:170:13
	str	q4, [x11, x12]
	.loc	1 171 13                        ; evidence/kernels.cpp:171:13
	str	q5, [x10, x12]
	.loc	1 159 9                         ; evidence/kernels.cpp:159:9
	add	x12, x12, #16
	cmp	x9, x12
	b.ne	LBB3_8
LBB3_9:
	.loc	1 174 9                         ; evidence/kernels.cpp:174:9
	cmp	w8, w3
	b.ge	LBB3_14
; %bb.10:
	mov	w12, w8
	sxtw	x8, w3
	sub	x9, x8, x12
	cmp	x9, #15
	b.hi	LBB3_15
LBB3_11:
	.loc	1 0 9 is_stmt 0                 ; evidence/kernels.cpp:0:9
	mov	x11, x12
LBB3_12:
	mov	x9, #0                          ; =0x0
	.loc	1 174 9                         ; evidence/kernels.cpp:174:9
	add	x10, x11, x8
	lsl	x13, x10, #2
	add	x10, x0, x13
	add	x12, x1, x13
	add	x13, x2, x13
	lsl	x16, x11, #2
	add	x14, x1, x16
	add	x15, x0, x16
	add	x16, x2, x16
	sub	x8, x8, x11
LBB3_13:                                ; =>This Inner Loop Header: Depth=1
	.loc	1 175 29 is_stmt 1              ; evidence/kernels.cpp:175:29
	ldr	s0, [x16, x9, lsl #2]
	.loc	1 175 39 is_stmt 0              ; evidence/kernels.cpp:175:39
	ldr	s1, [x15, x9, lsl #2]
	.loc	1 175 48                        ; evidence/kernels.cpp:175:48
	ldr	s2, [x14, x9, lsl #2]
	.loc	1 175 60                        ; evidence/kernels.cpp:175:60
	ldr	s3, [x10, x9, lsl #2]
	.loc	1 175 74                        ; evidence/kernels.cpp:175:74
	ldr	s4, [x12, x9, lsl #2]
	.loc	1 175 38                        ; evidence/kernels.cpp:175:38
	fmadd	s0, s1, s2, s0
	.loc	1 175 59                        ; evidence/kernels.cpp:175:59
	fmsub	s0, s3, s4, s0
	.loc	1 176 29 is_stmt 1              ; evidence/kernels.cpp:176:29
	ldr	s5, [x13, x9, lsl #2]
	.loc	1 176 43 is_stmt 0              ; evidence/kernels.cpp:176:43
	fmadd	s1, s1, s4, s5
	.loc	1 176 69                        ; evidence/kernels.cpp:176:69
	fmadd	s1, s3, s2, s1
	.loc	1 177 22 is_stmt 1              ; evidence/kernels.cpp:177:22
	str	s0, [x16, x9, lsl #2]
	.loc	1 177 40 is_stmt 0              ; evidence/kernels.cpp:177:40
	str	s1, [x13, x9, lsl #2]
	.loc	1 174 15 is_stmt 1              ; evidence/kernels.cpp:174:15
	add	x9, x9, #1
	.loc	1 174 9 is_stmt 0               ; evidence/kernels.cpp:174:9
	cmp	x8, x9
	b.ne	LBB3_13
LBB3_14:
	.loc	1 179 1 epilogue_begin is_stmt 1 ; evidence/kernels.cpp:179:1
	ldp	x20, x19, [sp, #32]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp], #48             ; 16-byte Folded Reload
	ret
LBB3_15:
	.loc	1 174 9                         ; evidence/kernels.cpp:174:9
	add	x10, x8, x12
	lsl	x15, x10, #2
	add	x4, x2, x15
	lsl	x13, x8, #3
	add	x5, x2, x13
	add	x6, x0, x13
	lsl	x10, x12, #2
	add	x16, x0, x10
	lsl	x14, x8, #2
	add	x17, x1, x15
	add	x3, x1, x10
	add	x7, x2, x14
	add	x19, x0, x14
	cmp	x4, x19
	ccmp	x16, x5, #2, lo
	cset	w11, lo
	add	x20, x1, x13
	cmp	x4, x20
	ccmp	x17, x5, #2, lo
	cset	w13, lo
	add	x21, x1, x14
	cmp	x4, x21
	ccmp	x3, x5, #2, lo
	cset	w14, lo
	add	x22, x2, x10
	cmp	x22, x6
	add	x23, x0, x15
	ccmp	x23, x7, #2, lo
	cset	w15, lo
	cmp	x22, x19
	ccmp	x16, x7, #2, lo
	cset	w16, lo
	cmp	x22, x20
	ccmp	x17, x7, #2, lo
	cset	w17, lo
	cmp	x22, x21
	ccmp	x3, x7, #2, lo
	cset	w3, lo
	cmp	x23, x5
	ccmp	x4, x6, #2, lo
	b.lo	LBB3_11
; %bb.16:
	tbnz	w11, #0, LBB3_11
; %bb.17:
	tbnz	w13, #0, LBB3_11
; %bb.18:
	tbnz	w14, #0, LBB3_11
; %bb.19:
	tbnz	w15, #0, LBB3_11
; %bb.20:
	tbnz	w16, #0, LBB3_11
; %bb.21:
	tbnz	w17, #0, LBB3_11
; %bb.22:
	tbnz	w3, #0, LBB3_11
; %bb.23:
	and	x13, x9, #0xfffffffffffffff8
	add	x11, x13, x12
	add	x12, x8, x12
	lsl	x12, x12, #2
	add	x12, x12, #16
	mov	x14, x1
	mov	x15, x2
	mov	x16, x0
	mov	x17, x13
LBB3_24:                                ; =>This Inner Loop Header: Depth=1
	.loc	1 175 29                        ; evidence/kernels.cpp:175:29
	add	x3, x15, x10
	ldp	q0, q1, [x3]
	.loc	1 175 39 is_stmt 0              ; evidence/kernels.cpp:175:39
	add	x4, x16, x10
	ldp	q2, q3, [x4]
	.loc	1 175 48                        ; evidence/kernels.cpp:175:48
	add	x4, x14, x10
	ldp	q4, q5, [x4]
	.loc	1 175 38                        ; evidence/kernels.cpp:175:38
	fmla.4s	v0, v4, v2
	fmla.4s	v1, v5, v3
	.loc	1 175 60                        ; evidence/kernels.cpp:175:60
	add	x4, x16, x12
	ldp	q6, q7, [x4, #-16]
	.loc	1 175 74                        ; evidence/kernels.cpp:175:74
	add	x4, x14, x12
	ldp	q16, q17, [x4, #-16]
	.loc	1 175 59                        ; evidence/kernels.cpp:175:59
	fmls.4s	v0, v16, v6
	fmls.4s	v1, v17, v7
	.loc	1 176 29 is_stmt 1              ; evidence/kernels.cpp:176:29
	add	x4, x15, x12
	ldp	q18, q19, [x4, #-16]
	.loc	1 176 43 is_stmt 0              ; evidence/kernels.cpp:176:43
	fmla.4s	v18, v16, v2
	fmla.4s	v19, v17, v3
	.loc	1 176 69                        ; evidence/kernels.cpp:176:69
	fmla.4s	v18, v4, v6
	fmla.4s	v19, v5, v7
	.loc	1 177 22 is_stmt 1              ; evidence/kernels.cpp:177:22
	stp	q0, q1, [x3]
	.loc	1 177 40 is_stmt 0              ; evidence/kernels.cpp:177:40
	stp	q18, q19, [x4, #-16]
	add	x16, x16, #32
	add	x15, x15, #32
	add	x14, x14, #32
	subs	x17, x17, #8
	b.ne	LBB3_24
; %bb.25:
	.loc	1 174 9 is_stmt 1               ; evidence/kernels.cpp:174:9
	cmp	x9, x13
	b.ne	LBB3_12
	b	LBB3_14
Ltmp6:
Lfunc_end3:
	.cfi_endproc
                                        ; -- End function
	.globl	_scalar_ic1                     ; -- Begin function scalar_ic1
	.p2align	2
_scalar_ic1:                            ; @scalar_ic1
Lfunc_begin4:
	.cfi_startproc
; %bb.0:
	.loc	1 204 9 prologue_end            ; evidence/kernels.cpp:204:9
	cmp	w3, #1
	b.lt	LBB4_5
; %bb.1:
	mov	w8, w3
	cmp	w3, #4
	b.hs	LBB4_6
; %bb.2:
	.loc	1 0 9 is_stmt 0                 ; evidence/kernels.cpp:0:9
	mov	x9, #0                          ; =0x0
LBB4_3:
	mov	x10, #0                         ; =0x0
	.loc	1 204 9                         ; evidence/kernels.cpp:204:9
	add	x11, x9, x8
	lsl	x13, x11, #2
	add	x11, x2, x13
	add	x12, x1, x13
	add	x13, x0, x13
	lsl	x16, x9, #2
	add	x14, x1, x16
	add	x15, x0, x16
	add	x16, x2, x16
	sub	x8, x8, x9
LBB4_4:                                 ; =>This Inner Loop Header: Depth=1
	.loc	1 205 29 is_stmt 1              ; evidence/kernels.cpp:205:29
	ldr	s0, [x16, x10, lsl #2]
	.loc	1 205 39 is_stmt 0              ; evidence/kernels.cpp:205:39
	ldr	s1, [x15, x10, lsl #2]
	.loc	1 205 48                        ; evidence/kernels.cpp:205:48
	ldr	s2, [x14, x10, lsl #2]
	.loc	1 205 60                        ; evidence/kernels.cpp:205:60
	ldr	s3, [x13, x10, lsl #2]
	.loc	1 205 74                        ; evidence/kernels.cpp:205:74
	ldr	s4, [x12, x10, lsl #2]
	.loc	1 205 38                        ; evidence/kernels.cpp:205:38
	fmadd	s0, s1, s2, s0
	.loc	1 205 59                        ; evidence/kernels.cpp:205:59
	fmsub	s0, s3, s4, s0
	.loc	1 206 29 is_stmt 1              ; evidence/kernels.cpp:206:29
	ldr	s5, [x11, x10, lsl #2]
	.loc	1 206 43 is_stmt 0              ; evidence/kernels.cpp:206:43
	fmadd	s1, s1, s4, s5
	.loc	1 206 69                        ; evidence/kernels.cpp:206:69
	fmadd	s1, s3, s2, s1
	.loc	1 207 22 is_stmt 1              ; evidence/kernels.cpp:207:22
	str	s0, [x16, x10, lsl #2]
	.loc	1 207 40 is_stmt 0              ; evidence/kernels.cpp:207:40
	str	s1, [x11, x10, lsl #2]
	.loc	1 204 15 is_stmt 1              ; evidence/kernels.cpp:204:15
	add	x10, x10, #1
	.loc	1 204 9 is_stmt 0               ; evidence/kernels.cpp:204:9
	cmp	x8, x10
	b.ne	LBB4_4
LBB4_5:
	.loc	1 209 1 is_stmt 1               ; evidence/kernels.cpp:209:1
	ret
LBB4_6:
	.loc	1 0 1 is_stmt 0                 ; evidence/kernels.cpp:0:1
	mov	x9, #0                          ; =0x0
	.loc	1 204 9 is_stmt 1               ; evidence/kernels.cpp:204:9
	lsl	x10, x8, #2
	add	x3, x2, x10
	lsl	x14, x8, #3
	add	x4, x0, x10
	add	x5, x2, x14
	add	x17, x1, x10
	cmp	x2, x0
	ccmp	x5, x0, #0, lo
	cset	w11, hi
	add	x16, x1, x14
	cmp	x3, x16
	ccmp	x17, x5, #2, lo
	cset	w12, lo
	cmp	x2, x1
	ccmp	x5, x1, #0, lo
	cset	w13, hi
	add	x6, x0, x14
	cmp	x6, x2
	ccmp	x0, x2, #2, hi
	cset	w14, lo
	cmp	x4, x2
	ccmp	x3, x0, #0, hi
	cset	w15, hi
	cmp	x16, x2
	ccmp	x1, x2, #2, hi
	cset	w16, lo
	cmp	x17, x2
	ccmp	x3, x1, #0, hi
	cset	w17, hi
	cmp	x4, x5
	ccmp	x3, x6, #2, lo
	b.lo	LBB4_3
; %bb.7:
	tbnz	w11, #0, LBB4_3
; %bb.8:
	tbnz	w12, #0, LBB4_3
; %bb.9:
	tbnz	w13, #0, LBB4_3
; %bb.10:
	tbnz	w14, #0, LBB4_3
; %bb.11:
	tbnz	w15, #0, LBB4_3
; %bb.12:
	tbnz	w16, #0, LBB4_3
; %bb.13:
	tbnz	w17, #0, LBB4_3
; %bb.14:
	and	x9, x8, #0x7ffffffc
	mov	x11, x9
	mov	x12, x1
	mov	x13, x0
	mov	x14, x2
LBB4_15:                                ; =>This Inner Loop Header: Depth=1
	.loc	1 205 29                        ; evidence/kernels.cpp:205:29
	ldr	q0, [x14]
	.loc	1 205 39 is_stmt 0              ; evidence/kernels.cpp:205:39
	ldr	q1, [x13]
	.loc	1 205 48                        ; evidence/kernels.cpp:205:48
	ldr	q2, [x12]
	.loc	1 205 38                        ; evidence/kernels.cpp:205:38
	fmla.4s	v0, v2, v1
	.loc	1 205 60                        ; evidence/kernels.cpp:205:60
	ldr	q3, [x13, x10]
	.loc	1 205 74                        ; evidence/kernels.cpp:205:74
	ldr	q4, [x12, x10]
	.loc	1 205 59                        ; evidence/kernels.cpp:205:59
	fmls.4s	v0, v4, v3
	.loc	1 206 29 is_stmt 1              ; evidence/kernels.cpp:206:29
	ldr	q5, [x14, x10]
	.loc	1 206 43 is_stmt 0              ; evidence/kernels.cpp:206:43
	fmla.4s	v5, v4, v1
	.loc	1 206 69                        ; evidence/kernels.cpp:206:69
	fmla.4s	v5, v2, v3
	.loc	1 207 22 is_stmt 1              ; evidence/kernels.cpp:207:22
	str	q0, [x14]
	.loc	1 207 40 is_stmt 0              ; evidence/kernels.cpp:207:40
	str	q5, [x14, x10]
	.loc	1 204 21 is_stmt 1              ; evidence/kernels.cpp:204:21
	add	x14, x14, #16
	add	x13, x13, #16
	add	x12, x12, #16
	subs	x11, x11, #4
	b.ne	LBB4_15
; %bb.16:
	.loc	1 204 9 is_stmt 0               ; evidence/kernels.cpp:204:9
	cmp	x9, x8
	b.ne	LBB4_3
	b	LBB4_5
Ltmp7:
Lfunc_end4:
	.cfi_endproc
                                        ; -- End function
	.globl	_scalar_ic2                     ; -- Begin function scalar_ic2
	.p2align	2
_scalar_ic2:                            ; @scalar_ic2
Lfunc_begin5:
	.cfi_startproc
; %bb.0:
	.loc	1 234 9 prologue_end is_stmt 1  ; evidence/kernels.cpp:234:9
	cmp	w3, #1
	b.lt	LBB5_5
; %bb.1:
	mov	w8, w3
	cmp	w3, #8
	b.hs	LBB5_6
; %bb.2:
	.loc	1 0 9 is_stmt 0                 ; evidence/kernels.cpp:0:9
	mov	x9, #0                          ; =0x0
LBB5_3:
	mov	x10, #0                         ; =0x0
	.loc	1 234 9                         ; evidence/kernels.cpp:234:9
	add	x11, x9, x8
	lsl	x13, x11, #2
	add	x11, x2, x13
	add	x12, x1, x13
	add	x13, x0, x13
	lsl	x16, x9, #2
	add	x14, x1, x16
	add	x15, x0, x16
	add	x16, x2, x16
	sub	x8, x8, x9
LBB5_4:                                 ; =>This Inner Loop Header: Depth=1
	.loc	1 235 29 is_stmt 1              ; evidence/kernels.cpp:235:29
	ldr	s0, [x16, x10, lsl #2]
	.loc	1 235 39 is_stmt 0              ; evidence/kernels.cpp:235:39
	ldr	s1, [x15, x10, lsl #2]
	.loc	1 235 48                        ; evidence/kernels.cpp:235:48
	ldr	s2, [x14, x10, lsl #2]
	.loc	1 235 60                        ; evidence/kernels.cpp:235:60
	ldr	s3, [x13, x10, lsl #2]
	.loc	1 235 74                        ; evidence/kernels.cpp:235:74
	ldr	s4, [x12, x10, lsl #2]
	.loc	1 235 38                        ; evidence/kernels.cpp:235:38
	fmadd	s0, s1, s2, s0
	.loc	1 235 59                        ; evidence/kernels.cpp:235:59
	fmsub	s0, s3, s4, s0
	.loc	1 236 29 is_stmt 1              ; evidence/kernels.cpp:236:29
	ldr	s5, [x11, x10, lsl #2]
	.loc	1 236 43 is_stmt 0              ; evidence/kernels.cpp:236:43
	fmadd	s1, s1, s4, s5
	.loc	1 236 69                        ; evidence/kernels.cpp:236:69
	fmadd	s1, s3, s2, s1
	.loc	1 237 22 is_stmt 1              ; evidence/kernels.cpp:237:22
	str	s0, [x16, x10, lsl #2]
	.loc	1 237 40 is_stmt 0              ; evidence/kernels.cpp:237:40
	str	s1, [x11, x10, lsl #2]
	.loc	1 234 15 is_stmt 1              ; evidence/kernels.cpp:234:15
	add	x10, x10, #1
	.loc	1 234 9 is_stmt 0               ; evidence/kernels.cpp:234:9
	cmp	x8, x10
	b.ne	LBB5_4
LBB5_5:
	.loc	1 239 1 is_stmt 1               ; evidence/kernels.cpp:239:1
	ret
LBB5_6:
	.loc	1 0 1 is_stmt 0                 ; evidence/kernels.cpp:0:1
	mov	x9, #0                          ; =0x0
	.loc	1 234 9 is_stmt 1               ; evidence/kernels.cpp:234:9
	lsl	x10, x8, #2
	add	x3, x2, x10
	lsl	x14, x8, #3
	add	x4, x0, x10
	add	x5, x2, x14
	add	x17, x1, x10
	cmp	x2, x0
	ccmp	x5, x0, #0, lo
	cset	w11, hi
	add	x16, x1, x14
	cmp	x3, x16
	ccmp	x17, x5, #2, lo
	cset	w12, lo
	cmp	x2, x1
	ccmp	x5, x1, #0, lo
	cset	w13, hi
	add	x6, x0, x14
	cmp	x6, x2
	ccmp	x0, x2, #2, hi
	cset	w14, lo
	cmp	x4, x2
	ccmp	x3, x0, #0, hi
	cset	w15, hi
	cmp	x16, x2
	ccmp	x1, x2, #2, hi
	cset	w16, lo
	cmp	x17, x2
	ccmp	x3, x1, #0, hi
	cset	w17, hi
	cmp	x4, x5
	ccmp	x3, x6, #2, lo
	b.lo	LBB5_3
; %bb.7:
	tbnz	w11, #0, LBB5_3
; %bb.8:
	tbnz	w12, #0, LBB5_3
; %bb.9:
	tbnz	w13, #0, LBB5_3
; %bb.10:
	tbnz	w14, #0, LBB5_3
; %bb.11:
	tbnz	w15, #0, LBB5_3
; %bb.12:
	tbnz	w16, #0, LBB5_3
; %bb.13:
	tbnz	w17, #0, LBB5_3
; %bb.14:
	and	x9, x8, #0x7ffffff8
	add	x11, x2, #16
	add	x12, x0, #16
	add	x13, x1, #16
	mov	x14, x9
LBB5_15:                                ; =>This Inner Loop Header: Depth=1
	.loc	1 235 29                        ; evidence/kernels.cpp:235:29
	ldp	q0, q1, [x11, #-16]
	.loc	1 235 39 is_stmt 0              ; evidence/kernels.cpp:235:39
	ldp	q2, q3, [x12, #-16]
	.loc	1 235 48                        ; evidence/kernels.cpp:235:48
	ldp	q4, q5, [x13, #-16]
	.loc	1 235 38                        ; evidence/kernels.cpp:235:38
	fmla.4s	v0, v4, v2
	fmla.4s	v1, v5, v3
	.loc	1 235 60                        ; evidence/kernels.cpp:235:60
	add	x15, x12, x10
	ldp	q6, q7, [x15, #-16]
	.loc	1 235 74                        ; evidence/kernels.cpp:235:74
	add	x15, x13, x10
	ldp	q16, q17, [x15, #-16]
	.loc	1 235 59                        ; evidence/kernels.cpp:235:59
	fmls.4s	v0, v16, v6
	fmls.4s	v1, v17, v7
	.loc	1 236 29 is_stmt 1              ; evidence/kernels.cpp:236:29
	add	x15, x11, x10
	ldp	q18, q19, [x15, #-16]
	.loc	1 236 43 is_stmt 0              ; evidence/kernels.cpp:236:43
	fmla.4s	v18, v16, v2
	fmla.4s	v19, v17, v3
	.loc	1 236 69                        ; evidence/kernels.cpp:236:69
	fmla.4s	v18, v4, v6
	fmla.4s	v19, v5, v7
	.loc	1 237 22 is_stmt 1              ; evidence/kernels.cpp:237:22
	stp	q0, q1, [x11, #-16]
	.loc	1 237 40 is_stmt 0              ; evidence/kernels.cpp:237:40
	stp	q18, q19, [x15, #-16]
	.loc	1 234 21 is_stmt 1              ; evidence/kernels.cpp:234:21
	add	x11, x11, #32
	add	x12, x12, #32
	add	x13, x13, #32
	subs	x14, x14, #8
	b.ne	LBB5_15
; %bb.16:
	.loc	1 234 9 is_stmt 0               ; evidence/kernels.cpp:234:9
	cmp	x9, x8
	b.ne	LBB5_3
	b	LBB5_5
Ltmp8:
Lfunc_end5:
	.cfi_endproc
                                        ; -- End function
	.section	__DWARF,__debug_abbrev,regular,debug
Lsection_abbrev:
	.byte	1                               ; Abbreviation Code
	.byte	17                              ; DW_TAG_compile_unit
	.byte	1                               ; DW_CHILDREN_yes
	.byte	37                              ; DW_AT_producer
	.byte	14                              ; DW_FORM_strp
	.byte	19                              ; DW_AT_language
	.byte	5                               ; DW_FORM_data2
	.byte	3                               ; DW_AT_name
	.byte	14                              ; DW_FORM_strp
	.ascii	"\202|"                         ; DW_AT_LLVM_sysroot
	.byte	14                              ; DW_FORM_strp
	.ascii	"\357\177"                      ; DW_AT_APPLE_sdk
	.byte	14                              ; DW_FORM_strp
	.byte	16                              ; DW_AT_stmt_list
	.byte	23                              ; DW_FORM_sec_offset
	.byte	27                              ; DW_AT_comp_dir
	.byte	14                              ; DW_FORM_strp
	.ascii	"\341\177"                      ; DW_AT_APPLE_optimized
	.byte	25                              ; DW_FORM_flag_present
	.byte	17                              ; DW_AT_low_pc
	.byte	1                               ; DW_FORM_addr
	.byte	18                              ; DW_AT_high_pc
	.byte	6                               ; DW_FORM_data4
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	2                               ; Abbreviation Code
	.byte	46                              ; DW_TAG_subprogram
	.byte	0                               ; DW_CHILDREN_no
	.byte	17                              ; DW_AT_low_pc
	.byte	1                               ; DW_FORM_addr
	.byte	18                              ; DW_AT_high_pc
	.byte	6                               ; DW_FORM_data4
	.ascii	"\347\177"                      ; DW_AT_APPLE_omit_frame_ptr
	.byte	25                              ; DW_FORM_flag_present
	.byte	122                             ; DW_AT_call_all_calls
	.byte	25                              ; DW_FORM_flag_present
	.byte	3                               ; DW_AT_name
	.byte	14                              ; DW_FORM_strp
	.byte	0                               ; EOM(1)
	.byte	0                               ; EOM(2)
	.byte	0                               ; EOM(3)
	.section	__DWARF,__debug_info,regular,debug
Lsection_info:
Lcu_begin0:
.set Lset0, Ldebug_info_end0-Ldebug_info_start0 ; Length of Unit
	.long	Lset0
Ldebug_info_start0:
	.short	4                               ; DWARF version number
.set Lset1, Lsection_abbrev-Lsection_abbrev ; Offset Into Abbrev. Section
	.long	Lset1
	.byte	8                               ; Address Size (in bytes)
	.byte	1                               ; Abbrev [1] 0xb:0x8e DW_TAG_compile_unit
	.long	0                               ; DW_AT_producer
	.short	33                              ; DW_AT_language
	.long	47                              ; DW_AT_name
	.long	153                             ; DW_AT_LLVM_sysroot
	.long	253                             ; DW_AT_APPLE_sdk
.set Lset2, Lline_table_start0-Lsection_line ; DW_AT_stmt_list
	.long	Lset2
	.long	264                             ; DW_AT_comp_dir
                                        ; DW_AT_APPLE_optimized
	.quad	Lfunc_begin0                    ; DW_AT_low_pc
.set Lset3, Lfunc_end5-Lfunc_begin0     ; DW_AT_high_pc
	.long	Lset3
	.byte	2                               ; Abbrev [2] 0x32:0x11 DW_TAG_subprogram
	.quad	Lfunc_begin0                    ; DW_AT_low_pc
.set Lset4, Lfunc_end0-Lfunc_begin0     ; DW_AT_high_pc
	.long	Lset4
                                        ; DW_AT_APPLE_omit_frame_ptr
                                        ; DW_AT_call_all_calls
	.long	349                             ; DW_AT_name
	.byte	2                               ; Abbrev [2] 0x43:0x11 DW_TAG_subprogram
	.quad	Lfunc_begin1                    ; DW_AT_low_pc
.set Lset5, Lfunc_end1-Lfunc_begin1     ; DW_AT_high_pc
	.long	Lset5
                                        ; DW_AT_APPLE_omit_frame_ptr
                                        ; DW_AT_call_all_calls
	.long	356                             ; DW_AT_name
	.byte	2                               ; Abbrev [2] 0x54:0x11 DW_TAG_subprogram
	.quad	Lfunc_begin2                    ; DW_AT_low_pc
.set Lset6, Lfunc_end2-Lfunc_begin2     ; DW_AT_high_pc
	.long	Lset6
                                        ; DW_AT_APPLE_omit_frame_ptr
                                        ; DW_AT_call_all_calls
	.long	362                             ; DW_AT_name
	.byte	2                               ; Abbrev [2] 0x65:0x11 DW_TAG_subprogram
	.quad	Lfunc_begin3                    ; DW_AT_low_pc
.set Lset7, Lfunc_end3-Lfunc_begin3     ; DW_AT_high_pc
	.long	Lset7
                                        ; DW_AT_APPLE_omit_frame_ptr
                                        ; DW_AT_call_all_calls
	.long	368                             ; DW_AT_name
	.byte	2                               ; Abbrev [2] 0x76:0x11 DW_TAG_subprogram
	.quad	Lfunc_begin4                    ; DW_AT_low_pc
.set Lset8, Lfunc_end4-Lfunc_begin4     ; DW_AT_high_pc
	.long	Lset8
                                        ; DW_AT_APPLE_omit_frame_ptr
                                        ; DW_AT_call_all_calls
	.long	375                             ; DW_AT_name
	.byte	2                               ; Abbrev [2] 0x87:0x11 DW_TAG_subprogram
	.quad	Lfunc_begin5                    ; DW_AT_low_pc
.set Lset9, Lfunc_end5-Lfunc_begin5     ; DW_AT_high_pc
	.long	Lset9
                                        ; DW_AT_APPLE_omit_frame_ptr
                                        ; DW_AT_call_all_calls
	.long	386                             ; DW_AT_name
	.byte	0                               ; End Of Children Mark
Ldebug_info_end0:
	.section	__DWARF,__debug_str,regular,debug
Linfo_string:
	.asciz	"Apple clang version 17.0.0 (clang-1700.0.13.5)" ; string offset=0
	.asciz	"/Users/runner/work/SpectralForge-Chimera-Amp-Matrix/SpectralForge-Chimera-Amp-Matrix/evidence/kernels.cpp" ; string offset=47
	.asciz	"/Applications/Xcode_16.4.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk" ; string offset=153
	.asciz	"MacOSX.sdk"                    ; string offset=253
	.asciz	"/Users/runner/work/SpectralForge-Chimera-Amp-Matrix/SpectralForge-Chimera-Amp-Matrix" ; string offset=264
	.asciz	"scalar"                        ; string offset=349
	.asciz	"neon4"                         ; string offset=356
	.asciz	"neon8"                         ; string offset=362
	.asciz	"neon16"                        ; string offset=368
	.asciz	"scalar_ic1"                    ; string offset=375
	.asciz	"scalar_ic2"                    ; string offset=386
	.section	__DWARF,__apple_names,regular,debug
Lnames_begin:
	.long	1212240712                      ; Header Magic
	.short	1                               ; Header Version
	.short	0                               ; Header Hash Function
	.long	6                               ; Header Bucket Count
	.long	6                               ; Header Hash Count
	.long	12                              ; Header Data Length
	.long	0                               ; HeaderData Die Offset Base
	.long	1                               ; HeaderData Atom Count
	.short	1                               ; DW_ATOM_die_offset
	.short	6                               ; DW_FORM_data4
	.long	0                               ; Bucket 0
	.long	1                               ; Bucket 1
	.long	-1                              ; Bucket 2
	.long	3                               ; Bucket 3
	.long	4                               ; Bucket 4
	.long	5                               ; Bucket 5
	.long	-73842376                       ; Hash in Bucket 0
	.long	268357741                       ; Hash in Bucket 1
	.long	458672155                       ; Hash in Bucket 1
	.long	268357737                       ; Hash in Bucket 3
	.long	265870684                       ; Hash in Bucket 4
	.long	-73842377                       ; Hash in Bucket 5
.set Lset10, LNames5-Lnames_begin       ; Offset in Bucket 0
	.long	Lset10
.set Lset11, LNames2-Lnames_begin       ; Offset in Bucket 1
	.long	Lset11
.set Lset12, LNames0-Lnames_begin       ; Offset in Bucket 1
	.long	Lset12
.set Lset13, LNames1-Lnames_begin       ; Offset in Bucket 3
	.long	Lset13
.set Lset14, LNames3-Lnames_begin       ; Offset in Bucket 4
	.long	Lset14
.set Lset15, LNames4-Lnames_begin       ; Offset in Bucket 5
	.long	Lset15
LNames5:
	.long	386                             ; scalar_ic2
	.long	1                               ; Num DIEs
	.long	135
	.long	0
LNames2:
	.long	362                             ; neon8
	.long	1                               ; Num DIEs
	.long	84
	.long	0
LNames0:
	.long	349                             ; scalar
	.long	1                               ; Num DIEs
	.long	50
	.long	0
LNames1:
	.long	356                             ; neon4
	.long	1                               ; Num DIEs
	.long	67
	.long	0
LNames3:
	.long	368                             ; neon16
	.long	1                               ; Num DIEs
	.long	101
	.long	0
LNames4:
	.long	375                             ; scalar_ic1
	.long	1                               ; Num DIEs
	.long	118
	.long	0
	.section	__DWARF,__apple_objc,regular,debug
Lobjc_begin:
	.long	1212240712                      ; Header Magic
	.short	1                               ; Header Version
	.short	0                               ; Header Hash Function
	.long	1                               ; Header Bucket Count
	.long	0                               ; Header Hash Count
	.long	12                              ; Header Data Length
	.long	0                               ; HeaderData Die Offset Base
	.long	1                               ; HeaderData Atom Count
	.short	1                               ; DW_ATOM_die_offset
	.short	6                               ; DW_FORM_data4
	.long	-1                              ; Bucket 0
	.section	__DWARF,__apple_namespac,regular,debug
Lnamespac_begin:
	.long	1212240712                      ; Header Magic
	.short	1                               ; Header Version
	.short	0                               ; Header Hash Function
	.long	1                               ; Header Bucket Count
	.long	0                               ; Header Hash Count
	.long	12                              ; Header Data Length
	.long	0                               ; HeaderData Die Offset Base
	.long	1                               ; HeaderData Atom Count
	.short	1                               ; DW_ATOM_die_offset
	.short	6                               ; DW_FORM_data4
	.long	-1                              ; Bucket 0
	.section	__DWARF,__apple_types,regular,debug
Ltypes_begin:
	.long	1212240712                      ; Header Magic
	.short	1                               ; Header Version
	.short	0                               ; Header Hash Function
	.long	1                               ; Header Bucket Count
	.long	0                               ; Header Hash Count
	.long	20                              ; Header Data Length
	.long	0                               ; HeaderData Die Offset Base
	.long	3                               ; HeaderData Atom Count
	.short	1                               ; DW_ATOM_die_offset
	.short	6                               ; DW_FORM_data4
	.short	3                               ; DW_ATOM_die_tag
	.short	5                               ; DW_FORM_data2
	.short	4                               ; DW_ATOM_type_flags
	.short	11                              ; DW_FORM_data1
	.long	-1                              ; Bucket 0
.subsections_via_symbols
	.section	__DWARF,__debug_line,regular,debug
Lsection_line:
Lline_table_start0:
